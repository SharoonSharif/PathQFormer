#!/usr/bin/env bash
until grep -qE "\[batch3b\].*done" "/workspace/logs/pod_batch3b.out" 2>/dev/null; do sleep 60; done
echo "[chain] $(date '+%F %T') marker found in /workspace/logs/pod_batch3b.out"
[ -f "/usr/bin/runpodctl.real" ] && mv -f "/usr/bin/runpodctl.real" "/usr/bin/runpodctl" && echo "[chain] restored runpodctl"
cd "/workspace/PathQFormer_pod3/PathQFormer" && setsid bash scripts/pod/batch4.sh 0  > /workspace/logs/pod_chained_$(date +%H%M%S).out 2>&1 < /dev/null &
echo "[chain] launched: bash scripts/pod/batch4.sh 0 "
