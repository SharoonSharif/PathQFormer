# COADREAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5561 ± 0.0462 | [0.499, 0.613] | 0.5457 | 0.2422 | 0.5999 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6016 | 0.8008 | 0.8008 | 1 / 6 | 5 / 58 |
| 1 | 0.5255 | 0.6549 | 0.6549 | 1 / 6 | 13 / 71 |
| 2 | 0.5769 | 0.6250 | 0.3365 | 1 / 7 | 5 / 45 |
| 3 | 0.5854 | 0.6450 | 0.5962 | 1 / 6 | 9 / 67 |
| 4 | 0.4909 | 0.8182 | 0.5333 | 1 / 6 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7088 ± 0.0928
