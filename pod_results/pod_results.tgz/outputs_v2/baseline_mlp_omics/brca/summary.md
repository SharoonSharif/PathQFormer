# BRCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5393 ± 0.1134 | [0.399, 0.680] | 0.5555 | 0.0844 | 0.6251 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5498 | 0.7131 | 0.5000 | 1 / 6 | 8 / 176 |
| 1 | 0.3428 | 0.6899 | 0.6095 | 1 / 6 | 9 / 168 |
| 2 | 0.5868 | 0.7129 | 0.6522 | 1 / 6 | 20 / 182 |
| 3 | 0.5881 | 0.7445 | 0.6123 | 4 / 9 | 7 / 166 |
| 4 | 0.6291 | 0.6992 | 0.5168 | 1 / 6 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7119 ± 0.0207
