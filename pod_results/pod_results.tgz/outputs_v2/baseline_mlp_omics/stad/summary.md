# STAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5156 ± 0.0466 | [0.458, 0.573] | 0.5400 | 0.2177 | 0.5499 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5066 | 0.5728 | 0.4768 | 1 / 6 | 10 / 42 |
| 1 | 0.4577 | 0.5147 | 0.4594 | 1 / 6 | 16 / 56 |
| 2 | 0.5347 | 0.6337 | 0.6337 | 1 / 6 | 16 / 101 |
| 3 | 0.4962 | 0.7231 | 0.5923 | 2 / 7 | 9 / 45 |
| 4 | 0.5827 | 0.5833 | 0.5484 | 1 / 6 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6055 ± 0.0781
