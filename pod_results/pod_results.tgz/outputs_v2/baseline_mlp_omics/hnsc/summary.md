# HNSC — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5429 ± 0.0166 | [0.522, 0.563] | 0.5428 | 0.2282 | 0.5397 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5254 | 0.5428 | 0.4848 | 1 / 6 | 16 / 56 |
| 1 | 0.5586 | 0.5792 | 0.5033 | 1 / 6 | 25 / 69 |
| 2 | 0.5468 | 0.7238 | 0.6449 | 1 / 6 | 18 / 75 |
| 3 | 0.5580 | 0.5676 | 0.5217 | 1 / 6 | 45 / 126 |
| 4 | 0.5256 | 0.5580 | 0.5580 | 1 / 6 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5943 ± 0.0736
