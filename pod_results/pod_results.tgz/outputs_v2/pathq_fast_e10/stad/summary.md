# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5591 ± 0.0856 | [0.453, 0.665] | 0.5723 | 0.1798 | 0.5696 |
| genomic_only | 0.5794 ± 0.0842 | [0.475, 0.684] | 0.5907 | 0.1911 | 0.5795 |
| wsi_only | 0.5734 ± 0.1137 | [0.432, 0.715] | 0.5830 | 0.1648 | 0.5993 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5597 ± 0.0773 |
| 20% | 0.5520 ± 0.0791 |
| 30% | 0.5668 ± 0.0789 |
| 50% | 0.5624 ± 0.0491 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4238 | 0.5132 | 0.4238 | 10 / 10 | 10 / 42 |
| 1 | 0.5924 | 0.6684 | 0.5924 | 10 / 10 | 16 / 56 |
| 2 | 0.5842 | 0.6820 | 0.5842 | 10 / 10 | 16 / 101 |
| 3 | 0.6538 | 0.6731 | 0.6538 | 10 / 10 | 9 / 45 |
| 4 | 0.5410 | 0.6001 | 0.5410 | 10 / 10 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6274 ± 0.0716
