# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5500 ± 0.0521 | [0.485, 0.615] | 0.5620 | 0.1776 | 0.5753 |
| genomic_only | 0.5475 ± 0.0541 | [0.480, 0.615] | 0.5585 | 0.1861 | 0.5564 |
| wsi_only | 0.5504 ± 0.0503 | [0.488, 0.613] | 0.5578 | 0.1818 | 0.5521 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5412 ± 0.0550 |
| 20% | 0.5473 ± 0.0517 |
| 30% | 0.5635 ± 0.0546 |
| 50% | 0.5413 ± 0.0350 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5588 | 0.6255 | 0.5588 | 10 / 10 | 16 / 56 |
| 1 | 0.6017 | 0.6157 | 0.6017 | 10 / 10 | 25 / 69 |
| 2 | 0.5964 | 0.6291 | 0.5964 | 10 / 10 | 18 / 75 |
| 3 | 0.5087 | 0.5575 | 0.5087 | 10 / 10 | 45 / 126 |
| 4 | 0.4846 | 0.5307 | 0.4846 | 10 / 10 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5917 ± 0.0448
