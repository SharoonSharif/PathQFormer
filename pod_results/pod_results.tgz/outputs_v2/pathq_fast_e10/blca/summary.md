# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6093 ± 0.0683 | [0.524, 0.694] | 0.5880 | 0.1712 | 0.6589 |
| genomic_only | 0.6192 ± 0.1032 | [0.491, 0.747] | 0.6020 | 0.1815 | 0.6547 |
| wsi_only | 0.5971 ± 0.0710 | [0.509, 0.685] | 0.5797 | 0.1832 | 0.6453 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6121 ± 0.0686 |
| 20% | 0.6110 ± 0.0656 |
| 30% | 0.6122 ± 0.0640 |
| 50% | 0.6014 ± 0.0660 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6423 | 0.6423 | 0.6423 | 10 / 10 | 25 / 70 |
| 1 | 0.5764 | 0.7050 | 0.5764 | 10 / 10 | 24 / 72 |
| 2 | 0.6773 | 0.6865 | 0.6773 | 10 / 10 | 23 / 75 |
| 3 | 0.5061 | 0.5703 | 0.5061 | 10 / 10 | 25 / 71 |
| 4 | 0.6446 | 0.7439 | 0.6446 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6696 ± 0.0664
