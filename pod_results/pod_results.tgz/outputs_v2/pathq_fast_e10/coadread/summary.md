# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6981 ± 0.0816 | [0.597, 0.799] | 0.6959 | 0.0871 | 0.6860 |
| genomic_only | 0.5837 ± 0.1075 | [0.450, 0.717] | 0.5712 | 0.0862 | 0.5177 |
| wsi_only | 0.6567 ± 0.0931 | [0.541, 0.772] | 0.6713 | 0.0858 | 0.6852 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6832 ± 0.0808 |
| 20% | 0.6856 ± 0.0799 |
| 30% | 0.6852 ± 0.0721 |
| 50% | 0.6549 ± 0.0737 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8171 | 0.8862 | 0.8171 | 10 / 10 | 5 / 58 |
| 1 | 0.6176 | 0.6176 | 0.6176 | 10 / 10 | 13 / 71 |
| 2 | 0.6490 | 0.8750 | 0.6490 | 10 / 10 | 5 / 45 |
| 3 | 0.6612 | 0.6612 | 0.6612 | 10 / 10 | 9 / 67 |
| 4 | 0.7455 | 0.7576 | 0.7455 | 10 / 10 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7595 ± 0.1216
