# COADREAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5679 ± 0.1101 | [0.431, 0.705] | 0.5660 | 0.1982 | 0.5132 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6789 | 0.9024 | 0.5732 | 2 / 7 | 5 / 58 |
| 1 | 0.3922 | 0.5471 | 0.5471 | 1 / 6 | 13 / 71 |
| 2 | 0.5385 | 0.5385 | 0.4808 | 1 / 7 | 5 / 45 |
| 3 | 0.6179 | 0.6612 | 0.4526 | 1 / 6 | 9 / 67 |
| 4 | 0.6121 | 0.7091 | 0.5394 | 1 / 6 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6717 ± 0.1484
