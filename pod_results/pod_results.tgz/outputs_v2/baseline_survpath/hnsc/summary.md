# HNSC — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5153 ± 0.0568 | [0.445, 0.586] | 0.5181 | 0.1985 | 0.5349 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5283 | 0.5951 | 0.4601 | 1 / 6 | 16 / 56 |
| 1 | 0.5595 | 0.6457 | 0.4677 | 4 / 9 | 25 / 69 |
| 2 | 0.4171 | 0.5457 | 0.5242 | 1 / 6 | 18 / 75 |
| 3 | 0.5240 | 0.5484 | 0.5025 | 1 / 6 | 45 / 126 |
| 4 | 0.5478 | 0.6280 | 0.6280 | 1 / 6 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5926 ± 0.0454
