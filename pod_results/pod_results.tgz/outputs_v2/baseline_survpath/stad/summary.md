# STAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6097 ± 0.0744 | [0.517, 0.702] | 0.5964 | 0.1986 | 0.6344 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6755 | 0.6854 | 0.5927 | 5 / 10 | 10 / 42 |
| 1 | 0.6149 | 0.6718 | 0.6218 | 1 / 6 | 16 / 56 |
| 2 | 0.6042 | 0.7550 | 0.6302 | 2 / 7 | 16 / 101 |
| 3 | 0.6654 | 0.6654 | 0.5769 | 1 / 6 | 9 / 45 |
| 4 | 0.4886 | 0.5316 | 0.4772 | 1 / 6 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6619 ± 0.0811
