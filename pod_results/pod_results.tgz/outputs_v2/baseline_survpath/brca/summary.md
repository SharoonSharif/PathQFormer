# BRCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5318 ± 0.1837 | [0.304, 0.760] | 0.5364 | 0.1754 | 0.5587 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4433 | 0.7268 | 0.4313 | 1 / 6 | 8 / 176 |
| 1 | 0.5434 | 0.7809 | 0.6558 | 1 / 6 | 9 / 168 |
| 2 | 0.7024 | 0.7034 | 0.6237 | 1 / 6 | 20 / 182 |
| 3 | 0.2687 | 0.3767 | 0.3590 | 1 / 6 | 7 / 166 |
| 4 | 0.7014 | 0.7860 | 0.7860 | 1 / 6 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6748 ± 0.1703
