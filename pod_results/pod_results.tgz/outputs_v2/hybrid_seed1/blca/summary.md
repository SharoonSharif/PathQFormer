# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5989 ± 0.1316 | [0.436, 0.762] | 0.5964 | 0.1521 | 0.6561 |
| genomic_only | 0.5730 ± 0.1159 | [0.429, 0.717] | 0.5757 | 0.1670 | 0.6039 |
| wsi_only | 0.5780 ± 0.1104 | [0.441, 0.715] | 0.5674 | 0.1638 | 0.6362 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5899 ± 0.1348 |
| 20% | 0.5938 ± 0.1210 |
| 30% | 0.6003 ± 0.1078 |
| 50% | 0.5900 ± 0.1099 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5885 | 0.6125 | 0.6125 | 4 / 9 | 25 / 70 |
| 1 | 0.4894 | 0.6557 | 0.6344 | 6 / 11 | 24 / 72 |
| 2 | 0.6926 | 0.6957 | 0.6588 | 10 / 15 | 23 / 75 |
| 3 | 0.4570 | 0.5486 | 0.5005 | 2 / 7 | 25 / 71 |
| 4 | 0.7669 | 0.7669 | 0.6619 | 5 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6559 ± 0.0826
