# HNSC — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.4715 ± 0.0658 | [0.390, 0.553] | 0.4716 | 0.2222 | 0.5106 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4456 | 0.5385 | 0.5210 | 1 / 6 | 16 / 56 |
| 1 | 0.3983 | 0.5904 | 0.4414 | 1 / 6 | 25 / 69 |
| 2 | 0.5389 | 0.7125 | 0.6798 | 3 / 8 | 18 / 75 |
| 3 | 0.5432 | 0.6063 | 0.5371 | 1 / 6 | 45 / 126 |
| 4 | 0.4317 | 0.5239 | 0.5239 | 1 / 6 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5943 ± 0.0745
