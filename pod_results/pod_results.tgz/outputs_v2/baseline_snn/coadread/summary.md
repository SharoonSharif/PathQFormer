# COADREAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5758 ± 0.1090 | [0.440, 0.711] | 0.5650 | 0.2367 | 0.5899 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6260 | 0.7439 | 0.5894 | 1 / 6 | 5 / 58 |
| 1 | 0.4824 | 0.6108 | 0.6108 | 1 / 6 | 13 / 71 |
| 2 | 0.7115 | 0.7115 | 0.4423 | 1 / 7 | 5 / 45 |
| 3 | 0.4472 | 0.6382 | 0.6382 | 1 / 6 | 9 / 67 |
| 4 | 0.6121 | 0.6303 | 0.4848 | 1 / 6 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6669 ± 0.0575
