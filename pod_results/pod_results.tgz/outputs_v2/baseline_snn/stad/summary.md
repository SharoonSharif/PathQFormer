# STAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.4535 ± 0.1156 | [0.310, 0.597] | 0.4573 | 0.2260 | 0.5113 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.3046 | 0.5132 | 0.5132 | 1 / 6 | 10 / 42 |
| 1 | 0.3921 | 0.4603 | 0.4603 | 1 / 6 | 16 / 56 |
| 2 | 0.6160 | 0.6302 | 0.6219 | 1 / 6 | 16 / 101 |
| 3 | 0.4769 | 0.6538 | 0.6346 | 1 / 6 | 9 / 45 |
| 4 | 0.4778 | 0.6035 | 0.5746 | 1 / 6 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5722 ± 0.0822
