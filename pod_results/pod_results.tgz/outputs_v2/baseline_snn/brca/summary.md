# BRCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5719 ± 0.1068 | [0.439, 0.705] | 0.5805 | 0.0863 | 0.6465 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5928 | 0.7569 | 0.5627 | 1 / 6 | 8 / 176 |
| 1 | 0.3926 | 0.8521 | 0.5128 | 1 / 6 | 9 / 168 |
| 2 | 0.5689 | 0.5739 | 0.5739 | 1 / 6 | 20 / 182 |
| 3 | 0.6542 | 0.7919 | 0.5209 | 6 / 11 | 7 / 166 |
| 4 | 0.6512 | 0.6512 | 0.6165 | 1 / 6 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7252 ± 0.1117
