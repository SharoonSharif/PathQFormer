# STAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.4860 ± 0.0688 | [0.401, 0.571] | 0.4932 | 0.1506 | 0.4657 |
| genomic_only | 0.5547 ± 0.1025 | [0.427, 0.682] | 0.5531 | 0.1594 | 0.5374 |
| wsi_only | 0.4754 ± 0.1468 | [0.293, 0.658] | 0.4945 | 0.1506 | 0.4643 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.4899 ± 0.0640 |
| 20% | 0.5047 ± 0.0445 |
| 30% | 0.5148 ± 0.0535 |
| 50% | 0.4963 ± 0.0225 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.3874 | 0.5364 | 0.4603 | 3 / 8 | 10 / 42 |
| 1 | 0.4957 | 0.6563 | 0.4180 | 2 / 7 | 16 / 56 |
| 2 | 0.4912 | 0.5701 | 0.5571 | 4 / 9 | 16 / 101 |
| 3 | 0.5808 | 0.6808 | 0.6577 | 4 / 9 | 9 / 45 |
| 4 | 0.4751 | 0.4933 | 0.4698 | 2 / 7 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5874 ± 0.0794
