# HNSC — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.4839 ± 0.0836 | [0.380, 0.588] | 0.4966 | 0.1496 | 0.4716 |
| genomic_only | 0.5130 ± 0.0726 | [0.423, 0.603] | 0.5184 | 0.1487 | 0.5421 |
| wsi_only | 0.4670 ± 0.0845 | [0.362, 0.572] | 0.4808 | 0.1543 | 0.4658 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.4955 ± 0.0757 |
| 20% | 0.4845 ± 0.0605 |
| 30% | 0.5087 ± 0.0811 |
| 50% | 0.5075 ± 0.0625 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4180 | 0.4935 | 0.4935 | 4 / 9 | 16 / 56 |
| 1 | 0.4199 | 0.5904 | 0.5670 | 2 / 7 | 25 / 69 |
| 2 | 0.6144 | 0.6144 | 0.5276 | 6 / 11 | 18 / 75 |
| 3 | 0.4486 | 0.5461 | 0.5461 | 2 / 7 | 45 / 126 |
| 4 | 0.5188 | 0.5529 | 0.5171 | 2 / 7 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5595 ± 0.0463
