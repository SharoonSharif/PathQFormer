# BRCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5475 ± 0.1384 | [0.376, 0.719] | 0.5320 | 0.0602 | 0.5509 |
| genomic_only | 0.5861 ± 0.1411 | [0.411, 0.761] | 0.5709 | 0.0598 | 0.5782 |
| wsi_only | 0.5403 ± 0.1239 | [0.386, 0.694] | 0.5465 | 0.0628 | 0.5135 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5326 ± 0.1054 |
| 20% | 0.5233 ± 0.1098 |
| 30% | 0.5435 ± 0.0726 |
| 50% | 0.5231 ± 0.0616 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6031 | 0.6031 | 0.5189 | 5 / 10 | 8 / 176 |
| 1 | 0.6586 | 0.7838 | 0.5092 | 2 / 7 | 9 / 168 |
| 2 | 0.5124 | 0.6095 | 0.5894 | 2 / 7 | 20 / 182 |
| 3 | 0.3216 | 0.3700 | 0.3238 | 3 / 8 | 7 / 166 |
| 4 | 0.6420 | 0.6771 | 0.6771 | 2 / 7 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6087 ± 0.1519
