# COADREAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6582 ± 0.1612 | [0.458, 0.858] | 0.6376 | 0.0655 | 0.6008 |
| genomic_only | 0.6060 ± 0.1344 | [0.439, 0.773] | 0.6308 | 0.0669 | 0.6152 |
| wsi_only | 0.6247 ± 0.1904 | [0.388, 0.861] | 0.5872 | 0.0700 | 0.5956 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6426 ± 0.1536 |
| 20% | 0.6137 ± 0.1556 |
| 30% | 0.6299 ± 0.1421 |
| 50% | 0.6040 ± 0.1402 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8008 | 0.8496 | 0.8496 | 14 / 19 | 5 / 58 |
| 1 | 0.4216 | 0.5216 | 0.4020 | 2 / 7 | 13 / 71 |
| 2 | 0.8173 | 0.9038 | 0.4423 | 6 / 12 | 5 / 45 |
| 3 | 0.6152 | 0.7019 | 0.5149 | 7 / 12 | 9 / 67 |
| 4 | 0.6364 | 0.7212 | 0.5333 | 4 / 9 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7396 ± 0.1486
