# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5648 ± 0.1181 | [0.418, 0.711] | 0.5822 | 0.1360 | 0.5570 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6789 | 0.7724 | 0.6789 | 10 / 10 | 5 / 58 |
| 1 | 0.5275 | 0.5647 | 0.5275 | 10 / 10 | 13 / 71 |
| 2 | 0.6731 | 0.6731 | 0.6731 | 10 / 10 | 5 / 45 |
| 3 | 0.3930 | 0.6640 | 0.3930 | 10 / 10 | 9 / 67 |
| 4 | 0.5515 | 0.7091 | 0.5515 | 10 / 10 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6766 ± 0.0757
