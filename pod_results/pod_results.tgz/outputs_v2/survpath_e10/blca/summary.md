# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5877 ± 0.0883 | [0.478, 0.697] | 0.5793 | 0.2729 | 0.6283 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6587 | 0.6587 | 0.6587 | 10 / 10 | 25 / 70 |
| 1 | 0.5851 | 0.6044 | 0.5851 | 10 / 10 | 24 / 72 |
| 2 | 0.6486 | 0.6691 | 0.6486 | 10 / 10 | 23 / 75 |
| 3 | 0.4391 | 0.5090 | 0.4391 | 10 / 10 | 25 / 71 |
| 4 | 0.6072 | 0.6950 | 0.6072 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6272 ± 0.0739
