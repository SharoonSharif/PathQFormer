# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5313 ± 0.0562 | [0.461, 0.601] | 0.5419 | 0.2640 | 0.5406 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5022 | 0.6052 | 0.5022 | 10 / 10 | 16 / 56 |
| 1 | 0.5483 | 0.6570 | 0.5483 | 10 / 10 | 25 / 69 |
| 2 | 0.5389 | 0.5772 | 0.5389 | 10 / 10 | 18 / 75 |
| 3 | 0.4580 | 0.5391 | 0.4580 | 10 / 10 | 45 / 126 |
| 4 | 0.6092 | 0.6468 | 0.6092 | 10 / 10 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6051 ± 0.0489
