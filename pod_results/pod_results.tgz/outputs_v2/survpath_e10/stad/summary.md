# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6092 ± 0.1187 | [0.462, 0.757] | 0.6195 | 0.3066 | 0.5492 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6722 | 0.7053 | 0.6722 | 10 / 10 | 10 / 42 |
| 1 | 0.5509 | 0.6494 | 0.5509 | 10 / 10 | 16 / 56 |
| 2 | 0.7809 | 0.7809 | 0.7809 | 10 / 10 | 16 / 101 |
| 3 | 0.5654 | 0.6577 | 0.5654 | 10 / 10 | 9 / 45 |
| 4 | 0.4765 | 0.5598 | 0.4765 | 10 / 10 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6706 ± 0.0810
