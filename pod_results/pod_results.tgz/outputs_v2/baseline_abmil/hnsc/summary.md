# HNSC — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5467 ± 0.0451 | [0.491, 0.603] | 0.5650 | 0.2292 | 0.5471 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4906 | 0.5864 | 0.5327 | 1 / 6 | 16 / 56 |
| 1 | 0.6120 | 0.6485 | 0.5201 | 3 / 8 | 25 / 69 |
| 2 | 0.5321 | 0.5648 | 0.5451 | 3 / 8 | 18 / 75 |
| 3 | 0.5339 | 0.5522 | 0.4635 | 3 / 8 | 45 / 126 |
| 4 | 0.5648 | 0.6297 | 0.5973 | 1 / 6 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5963 ± 0.0415
