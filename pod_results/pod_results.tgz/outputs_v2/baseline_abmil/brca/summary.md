# BRCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.4813 ± 0.1137 | [0.340, 0.623] | 0.5105 | 0.1153 | 0.5264 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4347 | 0.6838 | 0.5653 | 1 / 6 | 8 / 176 |
| 1 | 0.5491 | 0.7383 | 0.6444 | 1 / 6 | 9 / 168 |
| 2 | 0.5710 | 0.6860 | 0.6222 | 1 / 6 | 20 / 182 |
| 3 | 0.3018 | 0.3789 | 0.3656 | 3 / 8 | 7 / 166 |
| 4 | 0.5499 | 0.6207 | 0.5583 | 1 / 6 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6215 ± 0.1419
