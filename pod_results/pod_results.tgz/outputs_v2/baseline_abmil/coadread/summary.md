# COADREAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5833 ± 0.1583 | [0.387, 0.780] | 0.5739 | 0.1842 | 0.5667 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8252 | 0.8252 | 0.6463 | 1 / 6 | 5 / 58 |
| 1 | 0.4118 | 0.7078 | 0.5059 | 1 / 6 | 13 / 71 |
| 2 | 0.4808 | 0.7692 | 0.7019 | 4 / 10 | 5 / 45 |
| 3 | 0.5745 | 0.6206 | 0.5095 | 1 / 6 | 9 / 67 |
| 4 | 0.6242 | 0.7273 | 0.5455 | 1 / 6 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7300 ± 0.0759
