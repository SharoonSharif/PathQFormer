# STAD — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.4975 ± 0.0889 | [0.387, 0.608] | 0.4627 | 0.2207 | 0.4697 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.3444 | 0.6192 | 0.6192 | 1 / 6 | 10 / 42 |
| 1 | 0.5751 | 0.6010 | 0.6010 | 1 / 6 | 16 / 56 |
| 2 | 0.5194 | 0.6290 | 0.5842 | 1 / 6 | 16 / 101 |
| 3 | 0.5346 | 0.6000 | 0.5923 | 1 / 6 | 9 / 45 |
| 4 | 0.5141 | 0.5974 | 0.5591 | 1 / 6 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6093 ± 0.0140
