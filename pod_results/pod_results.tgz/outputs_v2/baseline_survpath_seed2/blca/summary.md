# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5974 ± 0.0468 | [0.539, 0.656] | 0.5925 | 0.1783 | 0.6290 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5692 | 0.6394 | 0.6212 | 2 / 7 | 25 / 70 |
| 1 | 0.5822 | 0.5822 | 0.4642 | 1 / 6 | 24 / 72 |
| 2 | 0.6045 | 0.6270 | 0.6158 | 1 / 6 | 23 / 75 |
| 3 | 0.5562 | 0.6374 | 0.4561 | 1 / 6 | 25 / 71 |
| 4 | 0.6748 | 0.6748 | 0.6489 | 1 / 6 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6322 ± 0.0332
