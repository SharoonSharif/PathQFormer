# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6220 ± 0.1046 | [0.492, 0.752] | 0.6209 | 0.1500 | 0.6659 |
| genomic_only | 0.5825 ± 0.1367 | [0.413, 0.752] | 0.5802 | 0.1641 | 0.6311 |
| wsi_only | 0.5747 ± 0.0869 | [0.467, 0.683] | 0.5581 | 0.1562 | 0.6036 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6225 ± 0.1049 |
| 20% | 0.6211 ± 0.0971 |
| 30% | 0.6064 ± 0.0988 |
| 50% | 0.6020 ± 0.0869 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5846 | 0.6192 | 0.6173 | 7 / 12 | 25 / 70 |
| 1 | 0.6451 | 0.6683 | 0.6093 | 9 / 14 | 24 / 72 |
| 2 | 0.6875 | 0.7367 | 0.7367 | 6 / 11 | 23 / 75 |
| 3 | 0.4618 | 0.5656 | 0.4797 | 2 / 7 | 25 / 71 |
| 4 | 0.7309 | 0.7309 | 0.7194 | 6 / 11 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6642 ± 0.0733
