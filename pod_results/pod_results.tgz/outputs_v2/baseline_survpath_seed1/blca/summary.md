# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5520 ± 0.1421 | [0.376, 0.728] | 0.5339 | 0.1778 | 0.6020 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5317 | 0.6721 | 0.6721 | 1 / 6 | 25 / 70 |
| 1 | 0.3868 | 0.5735 | 0.5097 | 1 / 6 | 24 / 72 |
| 2 | 0.7234 | 0.7234 | 0.5205 | 1 / 6 | 23 / 75 |
| 3 | 0.4504 | 0.4967 | 0.4703 | 1 / 6 | 25 / 71 |
| 4 | 0.6676 | 0.6763 | 0.5453 | 2 / 7 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6284 ± 0.0916
