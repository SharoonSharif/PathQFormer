# HNSC — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5358 ± 0.0364 | [0.491, 0.581] | 0.5366 | 0.3114 | 0.5215 |
| genomic_only | 0.5502 ± 0.0591 | [0.477, 0.624] | 0.5500 | 0.2925 | 0.5613 |
| wsi_only | 0.5347 ± 0.0468 | [0.477, 0.593] | 0.5384 | 0.3188 | 0.5161 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5379 ± 0.0377 |
| 20% | 0.5381 ± 0.0301 |
| 30% | 0.5390 ± 0.0272 |
| 50% | 0.5310 ± 0.0409 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5401 | 0.6163 | 0.5401 | 20 / 20 | 18 / 56 |
| 1 | 0.5680 | 0.6210 | 0.5680 | 20 / 20 | 28 / 69 |
| 2 | 0.4975 | 0.5986 | 0.4975 | 20 / 20 | 30 / 75 |
| 3 | 0.5739 | 0.6159 | 0.5739 | 20 / 20 | 80 / 126 |
| 4 | 0.4994 | 0.5161 | 0.4994 | 20 / 20 | 20 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5936 ± 0.0442
