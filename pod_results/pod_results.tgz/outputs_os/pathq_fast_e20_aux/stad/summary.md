# STAD — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6029 ± 0.0698 | [0.516, 0.690] | 0.6074 | 0.2775 | 0.6254 |
| genomic_only | 0.5818 ± 0.0784 | [0.484, 0.679] | 0.5819 | 0.2289 | 0.5910 |
| wsi_only | 0.5740 ± 0.0742 | [0.482, 0.666] | 0.5844 | 0.2807 | 0.5923 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6002 ± 0.0600 |
| 20% | 0.6009 ± 0.0634 |
| 30% | 0.6051 ± 0.0648 |
| 50% | 0.5912 ± 0.0650 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5795 | 0.7848 | 0.5795 | 20 / 20 | 10 / 42 |
| 1 | 0.6140 | 0.6170 | 0.6140 | 20 / 20 | 18 / 56 |
| 2 | 0.6760 | 0.6851 | 0.6760 | 20 / 20 | 40 / 101 |
| 3 | 0.6488 | 0.7291 | 0.6488 | 20 / 20 | 11 / 45 |
| 4 | 0.4962 | 0.5853 | 0.4962 | 20 / 20 | 41 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6803 ± 0.0812
