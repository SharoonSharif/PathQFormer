# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5990 ± 0.0742 | [0.507, 0.691] | 0.5958 | 0.2076 | 0.6684 |
| genomic_only | 0.6334 ± 0.0851 | [0.528, 0.739] | 0.6296 | 0.1836 | 0.6758 |
| wsi_only | 0.6039 ± 0.0559 | [0.534, 0.673] | 0.5945 | 0.2206 | 0.6638 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5989 ± 0.0695 |
| 20% | 0.5993 ± 0.0688 |
| 30% | 0.5976 ± 0.0809 |
| 50% | 0.6036 ± 0.0686 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6442 | 0.7135 | 0.6442 | 20 / 20 | 25 / 70 |
| 1 | 0.6083 | 0.6712 | 0.6083 | 20 / 20 | 24 / 72 |
| 2 | 0.6568 | 0.6855 | 0.6568 | 20 / 20 | 23 / 75 |
| 3 | 0.4712 | 0.5118 | 0.4712 | 20 / 20 | 25 / 71 |
| 4 | 0.6144 | 0.7525 | 0.6144 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6669 ± 0.0921
