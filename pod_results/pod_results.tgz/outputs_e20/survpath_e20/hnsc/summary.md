# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5313 ± 0.1127 | [0.391, 0.671] | 0.5259 | 0.4289 | 0.5236 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4949 | 0.6139 | 0.4949 | 20 / 20 | 16 / 56 |
| 1 | 0.4677 | 0.6279 | 0.4677 | 20 / 20 | 25 / 69 |
| 2 | 0.5118 | 0.5941 | 0.5118 | 20 / 20 | 18 / 75 |
| 3 | 0.4533 | 0.5511 | 0.4533 | 20 / 20 | 45 / 126 |
| 4 | 0.7287 | 0.7457 | 0.7287 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6266 ± 0.0727
