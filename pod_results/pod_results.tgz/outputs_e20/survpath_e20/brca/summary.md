# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5519 ± 0.1412 | [0.377, 0.727] | 0.5134 | 0.1307 | 0.5515 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5799 | 0.6615 | 0.5799 | 20 / 20 | 8 / 176 |
| 1 | 0.6444 | 0.7198 | 0.6444 | 20 / 20 | 9 / 168 |
| 2 | 0.5958 | 0.7018 | 0.5958 | 20 / 20 | 20 / 182 |
| 3 | 0.3040 | 0.4471 | 0.3040 | 20 / 20 | 7 / 166 |
| 4 | 0.6356 | 0.8180 | 0.6356 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6696 ± 0.1370
