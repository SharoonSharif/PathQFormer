# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5322 ± 0.1206 | [0.382, 0.682] | 0.5775 | 0.1194 | 0.5594 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6626 | 0.8780 | 0.6626 | 20 / 20 | 5 / 58 |
| 1 | 0.4549 | 0.6176 | 0.4549 | 20 / 20 | 13 / 71 |
| 2 | 0.6538 | 0.6538 | 0.6538 | 20 / 20 | 5 / 45 |
| 3 | 0.4959 | 0.6883 | 0.4959 | 20 / 20 | 9 / 67 |
| 4 | 0.3939 | 0.7030 | 0.3939 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7082 ± 0.1005
