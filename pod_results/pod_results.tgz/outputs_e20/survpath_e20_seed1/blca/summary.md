# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5821 ± 0.0953 | [0.464, 0.700] | 0.5863 | 0.2987 | 0.6456 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6673 | 0.7365 | 0.6673 | 20 / 20 | 25 / 70 |
| 1 | 0.5890 | 0.6132 | 0.5890 | 20 / 20 | 24 / 72 |
| 2 | 0.6537 | 0.7059 | 0.6537 | 20 / 20 | 23 / 75 |
| 3 | 0.4278 | 0.5637 | 0.4278 | 20 / 20 | 25 / 71 |
| 4 | 0.5727 | 0.6806 | 0.5727 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6600 ± 0.0705
