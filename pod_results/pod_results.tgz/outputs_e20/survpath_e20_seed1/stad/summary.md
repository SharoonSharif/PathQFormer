# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5944 ± 0.0537 | [0.528, 0.661] | 0.6026 | 0.2401 | 0.5364 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5563 | 0.6490 | 0.5563 | 20 / 20 | 10 / 42 |
| 1 | 0.6788 | 0.6943 | 0.6788 | 20 / 20 | 16 / 56 |
| 2 | 0.6172 | 0.7138 | 0.6172 | 20 / 20 | 16 / 101 |
| 3 | 0.5654 | 0.6962 | 0.5654 | 20 / 20 | 9 / 45 |
| 4 | 0.5544 | 0.5840 | 0.5544 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6674 ± 0.0524
