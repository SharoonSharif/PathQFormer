# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5956 ± 0.0630 | [0.517, 0.674] | 0.6006 | 0.2676 | 0.6325 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6712 | 0.7365 | 0.6712 | 20 / 20 | 25 / 70 |
| 1 | 0.6054 | 0.6199 | 0.6054 | 20 / 20 | 24 / 72 |
| 2 | 0.6055 | 0.7285 | 0.6055 | 20 / 20 | 23 / 75 |
| 3 | 0.4958 | 0.6619 | 0.4958 | 20 / 20 | 25 / 71 |
| 4 | 0.6000 | 0.6748 | 0.6000 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6843 ± 0.0485
