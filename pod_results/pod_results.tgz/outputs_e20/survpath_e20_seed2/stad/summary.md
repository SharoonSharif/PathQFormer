# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5787 ± 0.0613 | [0.503, 0.655] | 0.5800 | 0.3230 | 0.5037 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6026 | 0.6722 | 0.6026 | 20 / 20 | 10 / 42 |
| 1 | 0.6356 | 0.6960 | 0.6356 | 20 / 20 | 16 / 56 |
| 2 | 0.6278 | 0.7279 | 0.6278 | 20 / 20 | 16 / 101 |
| 3 | 0.5000 | 0.6538 | 0.5000 | 20 / 20 | 9 / 45 |
| 4 | 0.5276 | 0.5766 | 0.5276 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6653 ± 0.0568
