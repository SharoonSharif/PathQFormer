# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6244 ± 0.0731 | [0.534, 0.715] | 0.6239 | 0.2050 | 0.6838 |
| genomic_only | 0.6250 ± 0.0788 | [0.527, 0.723] | 0.6322 | 0.1812 | 0.6956 |
| wsi_only | 0.6009 ± 0.0898 | [0.489, 0.712] | 0.5987 | 0.2291 | 0.6378 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6229 ± 0.0711 |
| 20% | 0.6192 ± 0.0608 |
| 30% | 0.6207 ± 0.0688 |
| 50% | 0.6149 ± 0.0650 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6712 | 0.6798 | 0.6712 | 20 / 20 | 25 / 70 |
| 1 | 0.5658 | 0.6238 | 0.5658 | 20 / 20 | 24 / 72 |
| 2 | 0.6814 | 0.7090 | 0.6814 | 20 / 20 | 23 / 75 |
| 3 | 0.5260 | 0.6091 | 0.5260 | 20 / 20 | 25 / 71 |
| 4 | 0.6777 | 0.7266 | 0.6777 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6697 ± 0.0517
