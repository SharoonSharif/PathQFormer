# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6346 ± 0.0975 | [0.514, 0.756] | 0.6464 | 0.0725 | 0.6516 |
| genomic_only | 0.5671 ± 0.1803 | [0.343, 0.791] | 0.5986 | 0.0673 | 0.5921 |
| wsi_only | 0.6279 ± 0.1347 | [0.461, 0.795] | 0.6371 | 0.0851 | 0.6263 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6248 ± 0.0845 |
| 20% | 0.6024 ± 0.0940 |
| 30% | 0.6258 ± 0.0764 |
| 50% | 0.5854 ± 0.1056 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5086 | 0.6564 | 0.5086 | 20 / 20 | 8 / 176 |
| 1 | 0.7624 | 0.7624 | 0.7624 | 20 / 20 | 9 / 168 |
| 2 | 0.6047 | 0.7425 | 0.6047 | 20 / 20 | 20 / 182 |
| 3 | 0.6013 | 0.7181 | 0.6013 | 20 / 20 | 7 / 166 |
| 4 | 0.6961 | 0.7053 | 0.6961 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7169 ± 0.0404
