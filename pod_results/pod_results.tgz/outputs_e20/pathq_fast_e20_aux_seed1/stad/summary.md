# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5981 ± 0.0972 | [0.477, 0.719] | 0.6072 | 0.2081 | 0.6269 |
| genomic_only | 0.5344 ± 0.0798 | [0.435, 0.633] | 0.5540 | 0.2181 | 0.5504 |
| wsi_only | 0.5992 ± 0.0673 | [0.516, 0.683] | 0.6130 | 0.2034 | 0.6472 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5940 ± 0.0921 |
| 20% | 0.5866 ± 0.0807 |
| 30% | 0.5839 ± 0.0610 |
| 50% | 0.5674 ± 0.0937 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4437 | 0.5960 | 0.4437 | 20 / 20 | 10 / 42 |
| 1 | 0.7047 | 0.7081 | 0.7047 | 20 / 20 | 16 / 56 |
| 2 | 0.6396 | 0.6631 | 0.6396 | 20 / 20 | 16 / 101 |
| 3 | 0.5808 | 0.6538 | 0.5808 | 20 / 20 | 9 / 45 |
| 4 | 0.6216 | 0.6297 | 0.6216 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6502 ± 0.0415
