# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6277 ± 0.0729 | [0.537, 0.718] | 0.6333 | 0.2155 | 0.6828 |
| genomic_only | 0.5346 ± 0.1191 | [0.387, 0.683] | 0.5268 | 0.1931 | 0.5811 |
| wsi_only | 0.6350 ± 0.0622 | [0.558, 0.712] | 0.6400 | 0.2192 | 0.6836 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6229 ± 0.0739 |
| 20% | 0.6261 ± 0.0676 |
| 30% | 0.6201 ± 0.0748 |
| 50% | 0.6028 ± 0.0712 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6769 | 0.6875 | 0.6769 | 20 / 20 | 25 / 70 |
| 1 | 0.5377 | 0.6896 | 0.5377 | 20 / 20 | 24 / 72 |
| 2 | 0.6783 | 0.6967 | 0.6783 | 20 / 20 | 23 / 75 |
| 3 | 0.5590 | 0.5703 | 0.5590 | 20 / 20 | 25 / 71 |
| 4 | 0.6863 | 0.7209 | 0.6863 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6730 ± 0.0589
