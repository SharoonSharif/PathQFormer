# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5683 ± 0.1365 | [0.399, 0.738] | 0.6116 | 0.0808 | 0.6086 |
| genomic_only | 0.5386 ± 0.0618 | [0.462, 0.615] | 0.5214 | 0.0665 | 0.5731 |
| wsi_only | 0.5647 ± 0.1867 | [0.333, 0.797] | 0.6263 | 0.0826 | 0.5840 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5638 ± 0.1344 |
| 20% | 0.5573 ± 0.1285 |
| 30% | 0.5657 ± 0.1045 |
| 50% | 0.5668 ± 0.0943 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4948 | 0.6426 | 0.4948 | 20 / 20 | 8 / 176 |
| 1 | 0.6856 | 0.7155 | 0.6856 | 20 / 20 | 9 / 168 |
| 2 | 0.6639 | 0.6868 | 0.6639 | 20 / 20 | 20 / 182 |
| 3 | 0.3634 | 0.5793 | 0.3634 | 20 / 20 | 7 / 166 |
| 4 | 0.6337 | 0.6839 | 0.6337 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6616 ± 0.0529
