# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5913 ± 0.0661 | [0.509, 0.673] | 0.5943 | 0.1983 | 0.6013 |
| genomic_only | 0.6184 ± 0.0718 | [0.529, 0.708] | 0.6205 | 0.1930 | 0.6031 |
| wsi_only | 0.5992 ± 0.0653 | [0.518, 0.680] | 0.6005 | 0.1986 | 0.6275 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5882 ± 0.0667 |
| 20% | 0.5909 ± 0.0590 |
| 30% | 0.5957 ± 0.0629 |
| 50% | 0.5840 ± 0.0553 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5464 | 0.6589 | 0.5464 | 20 / 20 | 10 / 42 |
| 1 | 0.6546 | 0.6753 | 0.6546 | 20 / 20 | 16 / 56 |
| 2 | 0.6608 | 0.7220 | 0.6608 | 20 / 20 | 16 / 101 |
| 3 | 0.5846 | 0.6885 | 0.5846 | 20 / 20 | 9 / 45 |
| 4 | 0.5101 | 0.6431 | 0.5101 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6776 ± 0.0301
