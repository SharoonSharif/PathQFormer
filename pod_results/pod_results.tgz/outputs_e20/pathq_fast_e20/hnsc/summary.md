# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5838 ± 0.0311 | [0.545, 0.622] | 0.5962 | 0.2236 | 0.5921 |
| genomic_only | 0.5478 ± 0.0185 | [0.525, 0.571] | 0.5593 | 0.1896 | 0.5657 |
| wsi_only | 0.5850 ± 0.0294 | [0.548, 0.622] | 0.5922 | 0.2271 | 0.5916 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5776 ± 0.0271 |
| 20% | 0.5759 ± 0.0284 |
| 30% | 0.5945 ± 0.0189 |
| 50% | 0.5751 ± 0.0178 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5617 | 0.6415 | 0.5617 | 20 / 20 | 16 / 56 |
| 1 | 0.6364 | 0.6476 | 0.6364 | 20 / 20 | 25 / 69 |
| 2 | 0.5829 | 0.6685 | 0.5829 | 20 / 20 | 18 / 75 |
| 3 | 0.5598 | 0.5988 | 0.5598 | 20 / 20 | 45 / 126 |
| 4 | 0.5785 | 0.5836 | 0.5785 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6280 ± 0.0355
