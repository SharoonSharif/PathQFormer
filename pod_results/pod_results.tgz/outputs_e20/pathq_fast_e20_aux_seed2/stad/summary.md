# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5598 ± 0.0836 | [0.456, 0.664] | 0.5782 | 0.1968 | 0.5717 |
| genomic_only | 0.5386 ± 0.0861 | [0.432, 0.645] | 0.5523 | 0.2067 | 0.4944 |
| wsi_only | 0.5882 ± 0.0614 | [0.512, 0.665] | 0.6012 | 0.2039 | 0.6221 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5590 ± 0.0837 |
| 20% | 0.5649 ± 0.0628 |
| 30% | 0.5709 ± 0.0645 |
| 50% | 0.5495 ± 0.0522 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4305 | 0.7285 | 0.4305 | 20 / 20 | 10 / 42 |
| 1 | 0.5630 | 0.5976 | 0.5630 | 20 / 20 | 16 / 56 |
| 2 | 0.6455 | 0.6949 | 0.6455 | 20 / 20 | 16 / 101 |
| 3 | 0.6192 | 0.7077 | 0.6192 | 20 / 20 | 9 / 45 |
| 4 | 0.5410 | 0.5437 | 0.5410 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6545 ± 0.0798
