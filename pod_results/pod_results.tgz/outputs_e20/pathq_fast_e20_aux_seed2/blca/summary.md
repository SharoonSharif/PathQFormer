# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6417 ± 0.0642 | [0.562, 0.721] | 0.6405 | 0.1968 | 0.7180 |
| genomic_only | 0.6275 ± 0.0781 | [0.530, 0.725] | 0.6364 | 0.1867 | 0.6968 |
| wsi_only | 0.6020 ± 0.0945 | [0.485, 0.719] | 0.5950 | 0.2154 | 0.6692 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6401 ± 0.0666 |
| 20% | 0.6315 ± 0.0653 |
| 30% | 0.6368 ± 0.0655 |
| 50% | 0.6315 ± 0.0591 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6538 | 0.6817 | 0.6538 | 20 / 20 | 25 / 70 |
| 1 | 0.6480 | 0.6509 | 0.6480 | 20 / 20 | 24 / 72 |
| 2 | 0.6885 | 0.6906 | 0.6885 | 20 / 20 | 23 / 75 |
| 3 | 0.5316 | 0.5477 | 0.5316 | 20 / 20 | 25 / 71 |
| 4 | 0.6863 | 0.7094 | 0.6863 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6560 ± 0.0642
