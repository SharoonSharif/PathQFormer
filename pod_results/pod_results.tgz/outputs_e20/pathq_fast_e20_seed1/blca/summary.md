# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6015 ± 0.1023 | [0.475, 0.729] | 0.6071 | 0.2079 | 0.6542 |
| genomic_only | 0.6016 ± 0.1114 | [0.463, 0.740] | 0.6030 | 0.1785 | 0.6325 |
| wsi_only | 0.5964 ± 0.1031 | [0.468, 0.724] | 0.6008 | 0.2214 | 0.6394 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5967 ± 0.1001 |
| 20% | 0.6024 ± 0.0873 |
| 30% | 0.6074 ± 0.0752 |
| 50% | 0.6037 ± 0.0857 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6837 | 0.6865 | 0.6837 | 20 / 20 | 25 / 70 |
| 1 | 0.5532 | 0.7118 | 0.5532 | 20 / 20 | 24 / 72 |
| 2 | 0.6311 | 0.6670 | 0.6311 | 20 / 20 | 23 / 75 |
| 3 | 0.4476 | 0.5269 | 0.4476 | 20 / 20 | 25 / 71 |
| 4 | 0.6921 | 0.7885 | 0.6921 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6761 ± 0.0953
