# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5796 ± 0.0615 | [0.503, 0.656] | 0.5908 | 0.1899 | 0.5933 |
| genomic_only | 0.5549 ± 0.0600 | [0.480, 0.629] | 0.5665 | 0.1994 | 0.5406 |
| wsi_only | 0.5731 ± 0.0703 | [0.486, 0.660] | 0.5759 | 0.1883 | 0.5880 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5748 ± 0.0515 |
| 20% | 0.5705 ± 0.0474 |
| 30% | 0.5865 ± 0.0544 |
| 50% | 0.5550 ± 0.0418 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5596 | 0.5960 | 0.5596 | 20 / 20 | 10 / 42 |
| 1 | 0.6373 | 0.6788 | 0.6373 | 20 / 20 | 16 / 56 |
| 2 | 0.5948 | 0.6172 | 0.5948 | 20 / 20 | 16 / 101 |
| 3 | 0.6231 | 0.6769 | 0.6231 | 20 / 20 | 9 / 45 |
| 4 | 0.4832 | 0.5531 | 0.4832 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6244 ± 0.0540
