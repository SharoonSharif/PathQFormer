# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5798 ± 0.0457 | [0.523, 0.637] | 0.5904 | 0.2198 | 0.5761 |
| genomic_only | 0.5142 ± 0.0727 | [0.424, 0.605] | 0.5278 | 0.1776 | 0.5073 |
| wsi_only | 0.5962 ± 0.0643 | [0.516, 0.676] | 0.6064 | 0.2257 | 0.5917 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5799 ± 0.0512 |
| 20% | 0.5760 ± 0.0523 |
| 30% | 0.5602 ± 0.0527 |
| 50% | 0.5618 ± 0.0560 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6473 | 0.6807 | 0.6473 | 20 / 20 | 16 / 56 |
| 1 | 0.5895 | 0.6664 | 0.5895 | 20 / 20 | 25 / 69 |
| 2 | 0.5254 | 0.6505 | 0.5254 | 20 / 20 | 18 / 75 |
| 3 | 0.5839 | 0.5970 | 0.5839 | 20 / 20 | 45 / 126 |
| 4 | 0.5529 | 0.5922 | 0.5529 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6373 ± 0.0405
