# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6253 ± 0.0806 | [0.525, 0.725] | 0.6256 | 0.2123 | 0.6834 |
| genomic_only | 0.5878 ± 0.1103 | [0.451, 0.725] | 0.5831 | 0.1834 | 0.6589 |
| wsi_only | 0.5977 ± 0.0932 | [0.482, 0.713] | 0.5936 | 0.2217 | 0.6468 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6263 ± 0.0795 |
| 20% | 0.6249 ± 0.0801 |
| 30% | 0.6237 ± 0.0798 |
| 50% | 0.6175 ± 0.0825 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7115 | 0.7183 | 0.7115 | 20 / 20 | 25 / 70 |
| 1 | 0.5484 | 0.6489 | 0.5484 | 20 / 20 | 24 / 72 |
| 2 | 0.6670 | 0.7111 | 0.6670 | 20 / 20 | 23 / 75 |
| 3 | 0.5307 | 0.6185 | 0.5307 | 20 / 20 | 25 / 71 |
| 4 | 0.6691 | 0.8043 | 0.6691 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7002 ± 0.0717
