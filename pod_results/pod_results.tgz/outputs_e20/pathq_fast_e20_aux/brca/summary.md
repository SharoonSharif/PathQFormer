# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6474 ± 0.1395 | [0.474, 0.821] | 0.6236 | 0.0726 | 0.6826 |
| genomic_only | 0.6707 ± 0.1380 | [0.499, 0.842] | 0.6352 | 0.0677 | 0.6587 |
| wsi_only | 0.6095 ± 0.1623 | [0.408, 0.811] | 0.6113 | 0.0895 | 0.6246 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6427 ± 0.1285 |
| 20% | 0.6340 ± 0.1443 |
| 30% | 0.6418 ± 0.1151 |
| 50% | 0.6429 ± 0.0926 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6787 | 0.6976 | 0.6787 | 20 / 20 | 8 / 176 |
| 1 | 0.8094 | 0.8265 | 0.8094 | 20 / 20 | 9 / 168 |
| 2 | 0.7024 | 0.7150 | 0.7024 | 20 / 20 | 20 / 182 |
| 3 | 0.4317 | 0.6156 | 0.4317 | 20 / 20 | 7 / 166 |
| 4 | 0.6146 | 0.6858 | 0.6146 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7081 ± 0.0762
