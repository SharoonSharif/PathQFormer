# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6033 ± 0.0313 | [0.564, 0.642] | 0.6126 | 0.2109 | 0.6060 |
| genomic_only | 0.5745 ± 0.0563 | [0.505, 0.644] | 0.5770 | 0.2069 | 0.6389 |
| wsi_only | 0.6038 ± 0.0369 | [0.558, 0.650] | 0.6142 | 0.2167 | 0.5862 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5977 ± 0.0330 |
| 20% | 0.5970 ± 0.0340 |
| 30% | 0.6095 ± 0.0333 |
| 50% | 0.5897 ± 0.0301 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6096 | 0.7213 | 0.6096 | 20 / 20 | 16 / 56 |
| 1 | 0.6495 | 0.6589 | 0.6495 | 20 / 20 | 25 / 69 |
| 2 | 0.5738 | 0.6460 | 0.5738 | 20 / 20 | 18 / 75 |
| 3 | 0.5743 | 0.6383 | 0.5743 | 20 / 20 | 45 / 126 |
| 4 | 0.6092 | 0.6195 | 0.6092 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6568 ± 0.0388
