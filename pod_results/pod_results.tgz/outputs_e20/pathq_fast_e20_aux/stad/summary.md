# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5590 ± 0.0634 | [0.480, 0.638] | 0.5726 | 0.1986 | 0.5516 |
| genomic_only | 0.5413 ± 0.1015 | [0.415, 0.667] | 0.5696 | 0.2121 | 0.5528 |
| wsi_only | 0.5792 ± 0.0627 | [0.501, 0.657] | 0.5889 | 0.2012 | 0.6048 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5587 ± 0.0645 |
| 20% | 0.5612 ± 0.0516 |
| 30% | 0.5684 ± 0.0618 |
| 50% | 0.5543 ± 0.0389 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4669 | 0.6358 | 0.4669 | 20 / 20 | 10 / 42 |
| 1 | 0.6028 | 0.6235 | 0.6028 | 20 / 20 | 16 / 56 |
| 2 | 0.5995 | 0.6808 | 0.5995 | 20 / 20 | 16 / 101 |
| 3 | 0.6077 | 0.6538 | 0.6077 | 20 / 20 | 9 / 45 |
| 4 | 0.5181 | 0.6025 | 0.5181 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6393 ± 0.0298
