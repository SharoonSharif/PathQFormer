# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5951 ± 0.1519 | [0.406, 0.784] | 0.5804 | 0.0748 | 0.6719 |
| genomic_only | 0.5936 ± 0.1611 | [0.394, 0.794] | 0.6030 | 0.0862 | 0.6125 |
| wsi_only | 0.5474 ± 0.2076 | [0.290, 0.805] | 0.5435 | 0.0780 | 0.7041 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5896 ± 0.1506 |
| 20% | 0.5913 ± 0.1442 |
| 30% | 0.5840 ± 0.1746 |
| 50% | 0.5808 ± 0.1716 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8496 | 0.9268 | 0.8496 | 20 / 20 | 5 / 58 |
| 1 | 0.5392 | 0.6706 | 0.5392 | 20 / 20 | 13 / 71 |
| 2 | 0.4423 | 0.9135 | 0.4423 | 20 / 20 | 5 / 45 |
| 3 | 0.5745 | 0.7453 | 0.5745 | 20 / 20 | 9 / 67 |
| 4 | 0.5697 | 0.7091 | 0.5697 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7930 ± 0.1191
