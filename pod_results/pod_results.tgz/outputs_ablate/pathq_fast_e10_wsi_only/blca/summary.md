# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5957 ± 0.0925 | [0.481, 0.711] | 0.5869 | 0.1893 | 0.6483 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6250 | 0.6250 | 0.6250 | 10 / 10 | 25 / 70 |
| 1 | 0.5426 | 0.5832 | 0.5426 | 10 / 10 | 24 / 72 |
| 2 | 0.6332 | 0.6721 | 0.6332 | 10 / 10 | 23 / 75 |
| 3 | 0.4684 | 0.5940 | 0.4684 | 10 / 10 | 25 / 71 |
| 4 | 0.7094 | 0.7468 | 0.7094 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6442 ± 0.0669
