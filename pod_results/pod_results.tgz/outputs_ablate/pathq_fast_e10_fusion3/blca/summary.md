# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5947 ± 0.0877 | [0.486, 0.704] | 0.5943 | 0.1810 | 0.6463 |
| genomic_only | 0.6102 ± 0.0761 | [0.516, 0.705] | 0.6088 | 0.1828 | 0.6503 |
| wsi_only | 0.5849 ± 0.0810 | [0.484, 0.685] | 0.5826 | 0.1896 | 0.6272 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6006 ± 0.0868 |
| 20% | 0.5921 ± 0.0812 |
| 30% | 0.5963 ± 0.0812 |
| 50% | 0.5857 ± 0.0636 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5942 | 0.6269 | 0.5942 | 10 / 10 | 25 / 70 |
| 1 | 0.5416 | 0.6750 | 0.5416 | 10 / 10 | 24 / 72 |
| 2 | 0.6219 | 0.6301 | 0.6219 | 10 / 10 | 23 / 75 |
| 3 | 0.4920 | 0.5855 | 0.4920 | 10 / 10 | 25 / 71 |
| 4 | 0.7237 | 0.7396 | 0.7237 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6514 ± 0.0586
