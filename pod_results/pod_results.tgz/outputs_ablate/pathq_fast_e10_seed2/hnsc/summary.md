# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5636 ± 0.0476 | [0.505, 0.623] | 0.5771 | 0.1747 | 0.5752 |
| genomic_only | 0.5540 ± 0.0615 | [0.478, 0.630] | 0.5640 | 0.1882 | 0.5666 |
| wsi_only | 0.5492 ± 0.0442 | [0.494, 0.604] | 0.5565 | 0.1798 | 0.5557 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5570 ± 0.0495 |
| 20% | 0.5574 ± 0.0541 |
| 30% | 0.5408 ± 0.0427 |
| 50% | 0.5453 ± 0.0355 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5152 | 0.5370 | 0.5152 | 10 / 10 | 16 / 56 |
| 1 | 0.5717 | 0.5717 | 0.5717 | 10 / 10 | 25 / 69 |
| 2 | 0.5941 | 0.6753 | 0.5941 | 10 / 10 | 18 / 75 |
| 3 | 0.6218 | 0.6218 | 0.6218 | 10 / 10 | 45 / 126 |
| 4 | 0.5154 | 0.5631 | 0.5154 | 10 / 10 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5938 ± 0.0550
