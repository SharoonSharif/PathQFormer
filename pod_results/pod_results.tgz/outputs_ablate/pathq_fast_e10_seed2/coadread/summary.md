# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6289 ± 0.1902 | [0.393, 0.865] | 0.6223 | 0.0810 | 0.7618 |
| genomic_only | 0.6471 ± 0.1194 | [0.499, 0.795] | 0.6526 | 0.0720 | 0.6684 |
| wsi_only | 0.6213 ± 0.1728 | [0.407, 0.836] | 0.6085 | 0.0847 | 0.7240 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6294 ± 0.1917 |
| 20% | 0.6266 ± 0.1812 |
| 30% | 0.6229 ± 0.1955 |
| 50% | 0.6412 ± 0.1536 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8577 | 0.8577 | 0.8577 | 10 / 10 | 5 / 58 |
| 1 | 0.6667 | 0.7098 | 0.6667 | 10 / 10 | 13 / 71 |
| 2 | 0.7500 | 0.7500 | 0.7500 | 10 / 10 | 5 / 45 |
| 3 | 0.4580 | 0.6504 | 0.4580 | 10 / 10 | 9 / 67 |
| 4 | 0.4121 | 0.6000 | 0.4121 | 10 / 10 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7136 ± 0.0988
