# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6025 ± 0.0485 | [0.542, 0.663] | 0.6032 | 0.1686 | 0.6365 |
| genomic_only | 0.5641 ± 0.0905 | [0.452, 0.676] | 0.5721 | 0.1700 | 0.5674 |
| wsi_only | 0.6017 ± 0.0854 | [0.496, 0.708] | 0.5948 | 0.1685 | 0.6269 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5958 ± 0.0453 |
| 20% | 0.5973 ± 0.0590 |
| 30% | 0.5973 ± 0.0341 |
| 50% | 0.5845 ± 0.0344 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5563 | 0.7020 | 0.5563 | 10 / 10 | 10 / 42 |
| 1 | 0.5751 | 0.6045 | 0.5751 | 10 / 10 | 16 / 56 |
| 2 | 0.6714 | 0.6949 | 0.6714 | 10 / 10 | 16 / 101 |
| 3 | 0.6346 | 0.6769 | 0.6346 | 10 / 10 | 9 / 45 |
| 4 | 0.5749 | 0.6418 | 0.5749 | 10 / 10 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6640 ± 0.0406
