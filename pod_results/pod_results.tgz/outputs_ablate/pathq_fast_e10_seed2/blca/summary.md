# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6115 ± 0.1010 | [0.486, 0.737] | 0.5976 | 0.1762 | 0.6628 |
| genomic_only | 0.6061 ± 0.0985 | [0.484, 0.728] | 0.6050 | 0.1724 | 0.6548 |
| wsi_only | 0.6114 ± 0.0929 | [0.496, 0.727] | 0.5981 | 0.1848 | 0.6445 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6090 ± 0.0982 |
| 20% | 0.6083 ± 0.0921 |
| 30% | 0.6052 ± 0.1132 |
| 50% | 0.5997 ± 0.1071 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6538 | 0.6740 | 0.6538 | 10 / 10 | 25 / 70 |
| 1 | 0.6122 | 0.6528 | 0.6122 | 10 / 10 | 24 / 72 |
| 2 | 0.6793 | 0.6875 | 0.6793 | 10 / 10 | 23 / 75 |
| 3 | 0.4372 | 0.5392 | 0.4372 | 10 / 10 | 25 / 71 |
| 4 | 0.6748 | 0.7353 | 0.6748 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6578 ± 0.0729
