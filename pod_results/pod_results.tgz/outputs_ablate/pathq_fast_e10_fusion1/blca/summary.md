# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5977 ± 0.1236 | [0.444, 0.751] | 0.5976 | 0.1788 | 0.6531 |
| genomic_only | 0.6108 ± 0.0643 | [0.531, 0.691] | 0.6167 | 0.1758 | 0.6437 |
| wsi_only | 0.5836 ± 0.1183 | [0.437, 0.731] | 0.5839 | 0.1816 | 0.6352 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5989 ± 0.1173 |
| 20% | 0.5986 ± 0.1157 |
| 30% | 0.5943 ± 0.1079 |
| 50% | 0.5894 ± 0.0960 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6644 | 0.6933 | 0.6644 | 10 / 10 | 25 / 70 |
| 1 | 0.4652 | 0.6654 | 0.4652 | 10 / 10 | 24 / 72 |
| 2 | 0.6137 | 0.6475 | 0.6137 | 10 / 10 | 23 / 75 |
| 3 | 0.4854 | 0.5241 | 0.4854 | 10 / 10 | 25 / 71 |
| 4 | 0.7597 | 0.7813 | 0.7597 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6623 ± 0.0928
