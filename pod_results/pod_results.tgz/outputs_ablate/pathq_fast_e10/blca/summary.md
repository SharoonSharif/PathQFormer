# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6085 ± 0.0692 | [0.523, 0.694] | 0.5893 | 0.1670 | 0.6600 |
| genomic_only | 0.6295 ± 0.0673 | [0.546, 0.713] | 0.6185 | 0.1790 | 0.6767 |
| wsi_only | 0.6017 ± 0.0715 | [0.513, 0.691] | 0.5843 | 0.1856 | 0.6476 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6103 ± 0.0684 |
| 20% | 0.6137 ± 0.0663 |
| 30% | 0.6135 ± 0.0641 |
| 50% | 0.6028 ± 0.0670 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6490 | 0.6500 | 0.6490 | 10 / 10 | 25 / 70 |
| 1 | 0.5764 | 0.7050 | 0.5764 | 10 / 10 | 24 / 72 |
| 2 | 0.6762 | 0.6855 | 0.6762 | 10 / 10 | 23 / 75 |
| 3 | 0.5033 | 0.5703 | 0.5033 | 10 / 10 | 25 / 71 |
| 4 | 0.6374 | 0.7439 | 0.6374 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6709 ± 0.0657
