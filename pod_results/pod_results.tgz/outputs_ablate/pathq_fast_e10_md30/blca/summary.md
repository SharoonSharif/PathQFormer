# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6159 ± 0.0684 | [0.531, 0.701] | 0.6061 | 0.1710 | 0.6794 |
| genomic_only | 0.6475 ± 0.0891 | [0.537, 0.758] | 0.6400 | 0.1674 | 0.6824 |
| wsi_only | 0.6239 ± 0.0575 | [0.553, 0.695] | 0.6123 | 0.1813 | 0.6767 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6194 ± 0.0651 |
| 20% | 0.6160 ± 0.0685 |
| 30% | 0.6177 ± 0.0668 |
| 50% | 0.6091 ± 0.0718 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6558 | 0.6558 | 0.6558 | 10 / 10 | 25 / 70 |
| 1 | 0.5464 | 0.6896 | 0.5464 | 10 / 10 | 24 / 72 |
| 2 | 0.6660 | 0.6824 | 0.6660 | 10 / 10 | 23 / 75 |
| 3 | 0.5364 | 0.5703 | 0.5364 | 10 / 10 | 25 / 71 |
| 4 | 0.6748 | 0.7540 | 0.6748 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6704 ± 0.0666
