# BLCA — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6312 ± 0.0781 | [0.534, 0.728] | 0.6269 | 0.1574 | 0.6690 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6577 | nan | nan | -1 / 0 | 25 / 70 |
| 1 | 0.5542 | nan | nan | -1 / 0 | 24 / 72 |
| 2 | 0.6824 | nan | nan | -1 / 0 | 23 / 75 |
| 3 | 0.5439 | nan | nan | -1 / 0 | 25 / 71 |
| 4 | 0.7180 | nan | nan | -1 / 0 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
