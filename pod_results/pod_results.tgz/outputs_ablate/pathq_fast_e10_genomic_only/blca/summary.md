# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6029 ± 0.1100 | [0.466, 0.739] | 0.6002 | 0.1714 | 0.6425 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5875 | 0.6163 | 0.5875 | 10 / 10 | 25 / 70 |
| 1 | 0.4778 | 0.7389 | 0.4778 | 10 / 10 | 24 / 72 |
| 2 | 0.7561 | 0.7725 | 0.7561 | 10 / 10 | 23 / 75 |
| 3 | 0.5297 | 0.5940 | 0.5297 | 10 / 10 | 25 / 71 |
| 4 | 0.6633 | 0.7324 | 0.6633 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6908 ± 0.0801
