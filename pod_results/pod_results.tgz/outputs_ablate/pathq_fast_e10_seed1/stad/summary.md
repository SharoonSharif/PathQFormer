# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5605 ± 0.0711 | [0.472, 0.649] | 0.5685 | 0.1694 | 0.5565 |
| genomic_only | 0.5498 ± 0.1008 | [0.425, 0.675] | 0.5591 | 0.1840 | 0.5304 |
| wsi_only | 0.5271 ± 0.0969 | [0.407, 0.647] | 0.5199 | 0.1688 | 0.5105 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5517 ± 0.0638 |
| 20% | 0.5462 ± 0.0740 |
| 30% | 0.5622 ± 0.0591 |
| 50% | 0.5191 ± 0.0824 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5430 | 0.6424 | 0.5430 | 10 / 10 | 10 / 42 |
| 1 | 0.4819 | 0.6546 | 0.4819 | 10 / 10 | 16 / 56 |
| 2 | 0.5518 | 0.5518 | 0.5518 | 10 / 10 | 16 / 101 |
| 3 | 0.6769 | 0.6923 | 0.6769 | 10 / 10 | 9 / 45 |
| 4 | 0.5491 | 0.5692 | 0.5491 | 10 / 10 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6221 ± 0.0594
