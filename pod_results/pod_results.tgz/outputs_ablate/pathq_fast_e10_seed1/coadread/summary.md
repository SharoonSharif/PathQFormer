# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6102 ± 0.1508 | [0.423, 0.797] | 0.6230 | 0.0740 | 0.6566 |
| genomic_only | 0.5399 ± 0.0516 | [0.476, 0.604] | 0.5460 | 0.0808 | 0.4749 |
| wsi_only | 0.5435 ± 0.1348 | [0.376, 0.711] | 0.5427 | 0.0762 | 0.6541 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6017 ± 0.1533 |
| 20% | 0.6055 ± 0.1272 |
| 30% | 0.6168 ± 0.1519 |
| 50% | 0.5908 ± 0.1367 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8740 | 0.8984 | 0.8740 | 10 / 10 | 5 / 58 |
| 1 | 0.5314 | 0.5431 | 0.5314 | 10 / 10 | 13 / 71 |
| 2 | 0.5000 | 0.7115 | 0.5000 | 10 / 10 | 5 / 45 |
| 3 | 0.5637 | 0.7453 | 0.5637 | 10 / 10 | 9 / 67 |
| 4 | 0.5818 | 0.6303 | 0.5818 | 10 / 10 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7057 ± 0.1331
