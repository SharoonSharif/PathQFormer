# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5535 ± 0.0598 | [0.479, 0.628] | 0.5518 | 0.1824 | 0.5789 |
| genomic_only | 0.5224 ± 0.1004 | [0.398, 0.647] | 0.5368 | 0.1738 | 0.5389 |
| wsi_only | 0.5434 ± 0.0512 | [0.480, 0.607] | 0.5444 | 0.1829 | 0.5465 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5587 ± 0.0531 |
| 20% | 0.5566 ± 0.0585 |
| 30% | 0.5473 ± 0.0652 |
| 50% | 0.5543 ± 0.0541 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6081 | 0.6081 | 0.6081 | 10 / 10 | 16 / 56 |
| 1 | 0.5961 | 0.6204 | 0.5961 | 10 / 10 | 25 / 69 |
| 2 | 0.5750 | 0.6404 | 0.5750 | 10 / 10 | 18 / 75 |
| 3 | 0.4626 | 0.4833 | 0.4626 | 10 / 10 | 45 / 126 |
| 4 | 0.5256 | 0.5819 | 0.5256 | 10 / 10 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5868 ± 0.0616
