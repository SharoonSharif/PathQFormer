# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6337 ± 0.0917 | [0.520, 0.748] | 0.6315 | 0.1755 | 0.6767 |
| genomic_only | 0.6022 ± 0.1278 | [0.444, 0.761] | 0.6150 | 0.1774 | 0.6408 |
| wsi_only | 0.6053 ± 0.0877 | [0.496, 0.714] | 0.6002 | 0.1918 | 0.6325 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6295 ± 0.0927 |
| 20% | 0.6271 ± 0.0932 |
| 30% | 0.6337 ± 0.0859 |
| 50% | 0.6353 ± 0.1046 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6212 | 0.6298 | 0.6212 | 10 / 10 | 25 / 70 |
| 1 | 0.7147 | 0.7505 | 0.7147 | 10 / 10 | 24 / 72 |
| 2 | 0.6014 | 0.6527 | 0.6014 | 10 / 10 | 23 / 75 |
| 3 | 0.5033 | 0.5543 | 0.5033 | 10 / 10 | 25 / 71 |
| 4 | 0.7281 | 0.8115 | 0.7281 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6798 ± 0.1016
