# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6348 ± 0.1081 | [0.501, 0.769] | 0.6285 | 0.1685 | 0.6852 |
| genomic_only | 0.6256 ± 0.0623 | [0.548, 0.703] | 0.6264 | 0.1689 | 0.6728 |
| wsi_only | 0.5871 ± 0.1199 | [0.438, 0.736] | 0.5759 | 0.1763 | 0.6316 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6389 ± 0.1059 |
| 20% | 0.6322 ± 0.1000 |
| 30% | 0.6232 ± 0.1050 |
| 50% | 0.6022 ± 0.0959 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7019 | 0.7019 | 0.7019 | 10 / 10 | 25 / 70 |
| 1 | 0.5464 | 0.7108 | 0.5464 | 10 / 10 | 24 / 72 |
| 2 | 0.6947 | 0.7039 | 0.6947 | 10 / 10 | 23 / 75 |
| 3 | 0.4929 | 0.5963 | 0.4929 | 10 / 10 | 25 / 71 |
| 4 | 0.7381 | 0.7424 | 0.7381 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6911 ± 0.0554
