# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6003 ± 0.0543 | [0.533, 0.668] | 0.6119 | 0.2565 | 0.5995 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6226 | 0.6313 | 0.6226 | 10 / 10 | 16 / 56 |
| 1 | 0.5923 | 0.6448 | 0.5923 | 10 / 10 | 25 / 69 |
| 2 | 0.6122 | 0.6595 | 0.6122 | 10 / 10 | 18 / 75 |
| 3 | 0.5138 | 0.5394 | 0.5138 | 10 / 10 | 45 / 126 |
| 4 | 0.6604 | 0.6689 | 0.6604 | 10 / 10 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6288 ± 0.0520
