# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5934 ± 0.1015 | [0.467, 0.719] | 0.6111 | 0.2678 | 0.5416 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4735 | 0.5894 | 0.4735 | 10 / 10 | 10 / 42 |
| 1 | 0.6149 | 0.6252 | 0.6149 | 10 / 10 | 16 / 56 |
| 2 | 0.7444 | 0.7444 | 0.7444 | 10 / 10 | 16 / 101 |
| 3 | 0.6000 | 0.6231 | 0.6000 | 10 / 10 | 9 / 45 |
| 4 | 0.5343 | 0.5625 | 0.5343 | 10 / 10 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6289 ± 0.0696
