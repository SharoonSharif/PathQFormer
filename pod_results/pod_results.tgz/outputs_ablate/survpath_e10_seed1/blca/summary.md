# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5850 ± 0.0761 | [0.491, 0.679] | 0.5911 | 0.2839 | 0.6397 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6875 | 0.6942 | 0.6875 | 10 / 10 | 25 / 70 |
| 1 | 0.5735 | 0.5735 | 0.5735 | 10 / 10 | 24 / 72 |
| 2 | 0.6281 | 0.7059 | 0.6281 | 10 / 10 | 23 / 75 |
| 3 | 0.4891 | 0.5515 | 0.4891 | 10 / 10 | 25 / 71 |
| 4 | 0.5468 | 0.7036 | 0.5468 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6457 ± 0.0765
