# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5257 ± 0.1751 | [0.308, 0.743] | 0.5043 | 0.1098 | 0.5374 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8333 | 0.8415 | 0.8333 | 10 / 10 | 5 / 58 |
| 1 | 0.4843 | 0.6157 | 0.4843 | 10 / 10 | 13 / 71 |
| 2 | 0.4231 | 0.6923 | 0.4231 | 10 / 10 | 5 / 45 |
| 3 | 0.4092 | 0.6477 | 0.4092 | 10 / 10 | 9 / 67 |
| 4 | 0.4788 | 0.6848 | 0.4788 | 10 / 10 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6964 ± 0.0867
