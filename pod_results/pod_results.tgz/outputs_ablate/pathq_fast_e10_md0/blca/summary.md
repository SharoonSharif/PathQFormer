# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6341 ± 0.0749 | [0.541, 0.727] | 0.6297 | 0.1838 | 0.6934 |
| genomic_only | 0.5977 ± 0.0587 | [0.525, 0.671] | 0.5978 | 0.2313 | 0.6304 |
| wsi_only | 0.6089 ± 0.0922 | [0.494, 0.723] | 0.6005 | 0.2034 | 0.6456 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6334 ± 0.0816 |
| 20% | 0.6304 ± 0.0712 |
| 30% | 0.6218 ± 0.0693 |
| 50% | 0.6053 ± 0.0685 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6173 | 0.6183 | 0.6173 | 10 / 10 | 25 / 70 |
| 1 | 0.5716 | 0.6098 | 0.5716 | 10 / 10 | 24 / 72 |
| 2 | 0.6322 | 0.6619 | 0.6322 | 10 / 10 | 23 / 75 |
| 3 | 0.5883 | 0.5883 | 0.5883 | 10 / 10 | 25 / 71 |
| 4 | 0.7612 | 0.8201 | 0.7612 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6597 ± 0.0936
