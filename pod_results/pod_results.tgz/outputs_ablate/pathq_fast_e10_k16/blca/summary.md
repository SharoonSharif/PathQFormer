# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6380 ± 0.0699 | [0.551, 0.725] | 0.6333 | 0.1753 | 0.6888 |
| genomic_only | 0.6149 ± 0.0553 | [0.546, 0.684] | 0.6196 | 0.1738 | 0.6581 |
| wsi_only | 0.6145 ± 0.1012 | [0.489, 0.740] | 0.6087 | 0.1796 | 0.6603 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6361 ± 0.0724 |
| 20% | 0.6370 ± 0.0611 |
| 30% | 0.6252 ± 0.0648 |
| 50% | 0.6139 ± 0.0503 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6442 | 0.6663 | 0.6442 | 10 / 10 | 25 / 70 |
| 1 | 0.5667 | 0.6557 | 0.5667 | 10 / 10 | 24 / 72 |
| 2 | 0.6352 | 0.6486 | 0.6352 | 10 / 10 | 23 / 75 |
| 3 | 0.5940 | 0.5940 | 0.5940 | 10 / 10 | 25 / 71 |
| 4 | 0.7496 | 0.7856 | 0.7496 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6700 ± 0.0704
