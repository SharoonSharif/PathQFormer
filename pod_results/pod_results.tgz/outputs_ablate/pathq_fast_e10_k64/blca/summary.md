# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6343 ± 0.1270 | [0.477, 0.792] | 0.6278 | 0.1760 | 0.6743 |
| genomic_only | 0.6244 ± 0.0873 | [0.516, 0.733] | 0.6176 | 0.1691 | 0.6541 |
| wsi_only | 0.6191 ± 0.0895 | [0.508, 0.730] | 0.6074 | 0.1818 | 0.6568 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6356 ± 0.1188 |
| 20% | 0.6382 ± 0.1147 |
| 30% | 0.6228 ± 0.1052 |
| 50% | 0.6225 ± 0.1068 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6298 | 0.6356 | 0.6298 | 10 / 10 | 25 / 70 |
| 1 | 0.5909 | 0.6721 | 0.5909 | 10 / 10 | 24 / 72 |
| 2 | 0.7408 | 0.7408 | 0.7408 | 10 / 10 | 23 / 75 |
| 3 | 0.4476 | 0.5382 | 0.4476 | 10 / 10 | 25 / 71 |
| 4 | 0.7626 | 0.7626 | 0.7626 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6699 ± 0.0896
