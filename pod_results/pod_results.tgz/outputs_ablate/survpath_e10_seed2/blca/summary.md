# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5929 ± 0.0806 | [0.493, 0.693] | 0.5932 | 0.2751 | 0.6262 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6827 | 0.6971 | 0.6827 | 10 / 10 | 25 / 70 |
| 1 | 0.5638 | 0.5861 | 0.5638 | 10 / 10 | 24 / 72 |
| 2 | 0.6527 | 0.7326 | 0.6527 | 10 / 10 | 23 / 75 |
| 3 | 0.4769 | 0.6374 | 0.4769 | 10 / 10 | 25 / 71 |
| 4 | 0.5885 | 0.6748 | 0.5885 | 10 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6656 ± 0.0563
