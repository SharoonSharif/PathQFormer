# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6174 ± 0.0716 | [0.529, 0.706] | 0.6109 | 0.2912 | 0.5981 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6192 | 0.6887 | 0.6192 | 10 / 10 | 10 / 42 |
| 1 | 0.6218 | 0.7392 | 0.6218 | 10 / 10 | 16 / 56 |
| 2 | 0.7314 | 0.7468 | 0.7314 | 10 / 10 | 16 / 101 |
| 3 | 0.5462 | 0.7000 | 0.5462 | 10 / 10 | 9 / 45 |
| 4 | 0.5685 | 0.5773 | 0.5685 | 10 / 10 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6904 ± 0.0679
