# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5635 ± 0.1714 | [0.351, 0.776] | 0.5613 | 0.1277 | 0.5346 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7886 | 0.8374 | 0.7886 | 10 / 10 | 5 / 58 |
| 1 | 0.4569 | 0.6451 | 0.4569 | 10 / 10 | 13 / 71 |
| 2 | 0.3558 | 0.7788 | 0.3558 | 10 / 10 | 5 / 45 |
| 3 | 0.5434 | 0.7127 | 0.5434 | 10 / 10 | 9 / 67 |
| 4 | 0.6727 | 0.8182 | 0.6727 | 10 / 10 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7585 ± 0.0793
