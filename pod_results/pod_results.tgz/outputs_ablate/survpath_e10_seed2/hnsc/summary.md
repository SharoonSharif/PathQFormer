# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5738 ± 0.0319 | [0.534, 0.613] | 0.5745 | 0.2700 | 0.5568 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5776 | 0.6386 | 0.5776 | 10 / 10 | 16 / 56 |
| 1 | 0.6111 | 0.6448 | 0.6111 | 10 / 10 | 25 / 69 |
| 2 | 0.5964 | 0.6212 | 0.5964 | 10 / 10 | 18 / 75 |
| 3 | 0.5342 | 0.5854 | 0.5342 | 10 / 10 | 45 / 126 |
| 4 | 0.5495 | 0.6280 | 0.5495 | 10 / 10 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6236 ± 0.0232
