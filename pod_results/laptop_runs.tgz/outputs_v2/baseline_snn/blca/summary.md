# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.4985 ± 0.0575 | [0.427, 0.570] | 0.4960 | 0.2108 | 0.5931 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5308 | 0.5846 | 0.5394 | 1 / 6 | 25 / 70 |
| 1 | 0.4159 | 0.6315 | 0.5513 | 2 / 7 | 24 / 72 |
| 2 | 0.4662 | 0.7592 | 0.7592 | 1 / 6 | 23 / 75 |
| 3 | 0.5184 | 0.6478 | 0.5364 | 1 / 6 | 25 / 71 |
| 4 | 0.5612 | 0.6403 | 0.5669 | 1 / 6 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6527 ± 0.0644
