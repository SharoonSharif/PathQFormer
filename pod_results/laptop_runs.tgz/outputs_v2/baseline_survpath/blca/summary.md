# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5592 ± 0.1193 | [0.411, 0.707] | 0.5628 | 0.1756 | 0.5713 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4673 | 0.6596 | 0.6596 | 1 / 6 | 25 / 70 |
| 1 | 0.5919 | 0.5919 | 0.4439 | 2 / 7 | 24 / 72 |
| 2 | 0.5635 | 0.6096 | 0.5184 | 1 / 6 | 23 / 75 |
| 3 | 0.4353 | 0.5496 | 0.4967 | 1 / 6 | 25 / 71 |
| 4 | 0.7381 | 0.7381 | 0.6374 | 1 / 6 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6298 ± 0.0723
