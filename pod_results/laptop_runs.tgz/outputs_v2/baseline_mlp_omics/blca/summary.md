# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5714 ± 0.0793 | [0.473, 0.670] | 0.5642 | 0.2014 | 0.6166 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5529 | 0.5865 | 0.5865 | 1 / 6 | 25 / 70 |
| 1 | 0.5145 | 0.6422 | 0.6422 | 3 / 8 | 24 / 72 |
| 2 | 0.7008 | 0.7818 | 0.7377 | 1 / 6 | 23 / 75 |
| 3 | 0.5033 | 0.6733 | 0.5836 | 1 / 6 | 25 / 71 |
| 4 | 0.5856 | 0.6878 | 0.6518 | 1 / 6 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6743 ± 0.0715
