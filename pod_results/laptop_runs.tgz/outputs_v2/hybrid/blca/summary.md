# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6447 ± 0.0859 | [0.538, 0.751] | 0.6243 | 0.1546 | 0.7082 |
| genomic_only | 0.6283 ± 0.0951 | [0.510, 0.746] | 0.6183 | 0.1595 | 0.6413 |
| wsi_only | 0.5906 ± 0.0862 | [0.484, 0.698] | 0.5691 | 0.1796 | 0.6484 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6473 ± 0.0892 |
| 20% | 0.6390 ± 0.0906 |
| 30% | 0.6209 ± 0.0836 |
| 50% | 0.6233 ± 0.0884 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6000 | 0.6375 | 0.6192 | 6 / 11 | 25 / 70 |
| 1 | 0.6354 | 0.6393 | 0.6393 | 7 / 12 | 24 / 72 |
| 2 | 0.7008 | 0.7008 | 0.6588 | 10 / 15 | 23 / 75 |
| 3 | 0.5335 | 0.6138 | 0.6006 | 2 / 7 | 25 / 71 |
| 4 | 0.7540 | 0.7540 | 0.5842 | 6 / 11 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6691 ± 0.0573
