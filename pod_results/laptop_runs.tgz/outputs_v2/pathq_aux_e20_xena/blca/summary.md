# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6283 ± 0.0625 | [0.551, 0.706] | 0.6241 | 0.2238 | 0.6655 |
| genomic_only | 0.6339 ± 0.0760 | [0.540, 0.728] | 0.6457 | 0.1830 | 0.6878 |
| wsi_only | 0.6038 ± 0.0712 | [0.515, 0.692] | 0.5956 | 0.2259 | 0.6381 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6307 ± 0.0656 |
| 20% | 0.6287 ± 0.0625 |
| 30% | 0.6256 ± 0.0674 |
| 50% | 0.6146 ± 0.0570 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6067 | 0.6356 | 0.6067 | 20 / 20 | 25 / 70 |
| 1 | 0.6567 | 0.6576 | 0.6567 | 20 / 20 | 24 / 72 |
| 2 | 0.6516 | 0.6701 | 0.6516 | 20 / 20 | 23 / 75 |
| 3 | 0.5316 | 0.5836 | 0.5316 | 20 / 20 | 25 / 71 |
| 4 | 0.6950 | 0.7525 | 0.6950 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6599 ± 0.0615
