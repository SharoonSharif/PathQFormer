# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6000 ± 0.0753 | [0.507, 0.693] | 0.6053 | 0.2222 | 0.6733 |
| genomic_only | 0.5544 ± 0.0800 | [0.455, 0.654] | 0.5523 | 0.2174 | 0.6350 |
| wsi_only | 0.6078 ± 0.0772 | [0.512, 0.704] | 0.6024 | 0.2458 | 0.6507 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5998 ± 0.0739 |
| 20% | 0.6060 ± 0.0712 |
| 30% | 0.5964 ± 0.0659 |
| 50% | 0.5972 ± 0.0689 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6269 | 0.6577 | 0.6269 | 20 / 20 | 25 / 70 |
| 1 | 0.5629 | 0.6277 | 0.5629 | 20 / 20 | 24 / 72 |
| 2 | 0.7172 | 0.7305 | 0.7172 | 20 / 20 | 23 / 75 |
| 3 | 0.5231 | 0.5505 | 0.5231 | 20 / 20 | 25 / 71 |
| 4 | 0.5698 | 0.7482 | 0.5698 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6629 ± 0.0802
