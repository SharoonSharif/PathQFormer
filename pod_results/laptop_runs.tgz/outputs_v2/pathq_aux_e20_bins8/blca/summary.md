# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6093 ± 0.0815 | [0.508, 0.711] | 0.5962 | 0.1935 | 0.6444 |
| genomic_only | 0.6054 ± 0.0676 | [0.521, 0.689] | 0.6000 | 0.1847 | 0.6345 |
| wsi_only | 0.5785 ± 0.1152 | [0.435, 0.721] | 0.5644 | 0.2180 | 0.6083 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6172 ± 0.0872 |
| 20% | 0.6192 ± 0.0718 |
| 30% | 0.6105 ± 0.0809 |
| 50% | 0.6043 ± 0.0858 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6837 | 0.6846 | 0.6837 | 20 / 20 | 25 / 70 |
| 1 | 0.5629 | 0.6905 | 0.5629 | 20 / 20 | 24 / 72 |
| 2 | 0.6711 | 0.7223 | 0.6711 | 20 / 20 | 23 / 75 |
| 3 | 0.4901 | 0.5826 | 0.4901 | 20 / 20 | 25 / 71 |
| 4 | 0.6388 | 0.7453 | 0.6388 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6851 ± 0.0623
