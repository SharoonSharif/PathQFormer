# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.6183 ± 0.0426 | [0.565, 0.671] | 0.6202 | 0.1575 | 0.6669 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6615 | 0.7154 | 0.6962 | 6 / 11 | 25 / 70 |
| 1 | 0.5706 | 0.6267 | 0.5387 | 2 / 7 | 24 / 72 |
| 2 | 0.6137 | 0.6834 | 0.6650 | 6 / 11 | 23 / 75 |
| 3 | 0.5836 | 0.5836 | 0.5798 | 2 / 7 | 25 / 71 |
| 4 | 0.6619 | 0.6619 | 0.6144 | 3 / 8 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6542 ± 0.0510
