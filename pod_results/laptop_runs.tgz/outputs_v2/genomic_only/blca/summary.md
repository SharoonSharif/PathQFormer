# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6463 ± 0.0696 | [0.560, 0.733] | 0.6279 | 0.1526 | 0.6492 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6067 | 0.6067 | 0.5962 | 2 / 7 | 25 / 70 |
| 1 | 0.6306 | 0.6818 | 0.6499 | 6 / 11 | 24 / 72 |
| 2 | 0.7377 | 0.7377 | 0.6670 | 7 / 12 | 23 / 75 |
| 3 | 0.5628 | 0.6034 | 0.5807 | 2 / 7 | 25 / 71 |
| 4 | 0.6935 | 0.6935 | 0.5813 | 4 / 9 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6646 ± 0.0582
