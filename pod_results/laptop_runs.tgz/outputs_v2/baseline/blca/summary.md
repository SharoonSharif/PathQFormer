# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5744 ± 0.0949 | [0.456, 0.692] | 0.5655 | 0.1815 | 0.5964 |
| genomic_only | 0.5915 ± 0.0492 | [0.530, 0.653] | 0.5973 | 0.1819 | 0.6163 |
| wsi_only | 0.5504 ± 0.0656 | [0.469, 0.632] | 0.5468 | 0.1863 | 0.5777 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5700 ± 0.0847 |
| 20% | 0.5554 ± 0.0796 |
| 30% | 0.5631 ± 0.0718 |
| 50% | 0.5408 ± 0.0488 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6212 | 0.6274 | 0.6058 | 3 / 8 | 25 / 70 |
| 1 | 0.6088 | 0.6920 | 0.5986 | 2 / 7 | 24 / 72 |
| 2 | 0.5871 | 0.7070 | 0.6414 | 3 / 8 | 23 / 75 |
| 3 | 0.4089 | 0.5930 | 0.5930 | 4 / 9 | 25 / 71 |
| 4 | 0.6460 | 0.7209 | 0.7209 | 5 / 10 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6680 ± 0.0551
