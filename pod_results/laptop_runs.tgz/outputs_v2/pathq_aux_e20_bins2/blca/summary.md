# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6278 ± 0.0567 | [0.557, 0.698] | 0.6433 | nan | 0.6147 |
| genomic_only | 0.5755 ± 0.0937 | [0.459, 0.692] | 0.6043 | nan | 0.6071 |
| rna_permuted | 0.6192 ± 0.0879 | [0.510, 0.728] | 0.6244 | nan | 0.6144 |
| wsi_only | 0.6339 ± 0.0612 | [0.558, 0.710] | 0.6454 | nan | 0.6129 |
| wsi_permuted | 0.5713 ± 0.0751 | [0.478, 0.664] | 0.6095 | nan | 0.6148 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6266 ± 0.0626 |
| 20% | 0.6279 ± 0.0614 |
| 30% | 0.6204 ± 0.0609 |
| 50% | 0.6161 ± 0.0863 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6096 | 0.6471 | 0.6096 | 20 / 20 | 25 / 70 |
| 1 | 0.5967 | 0.6277 | 0.5967 | 20 / 20 | 24 / 72 |
| 2 | 0.6936 | 0.7387 | 0.6936 | 20 / 20 | 23 / 75 |
| 3 | 0.5600 | 0.6025 | 0.5600 | 20 / 20 | 25 / 71 |
| 4 | 0.6791 | 0.7439 | 0.6791 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6720 ± 0.0653
