# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6264 ± 0.0591 | [0.553, 0.700] | 0.6291 | 0.2078 | 0.6876 |
| genomic_only | 0.6221 ± 0.0942 | [0.505, 0.739] | 0.6255 | 0.1938 | 0.6623 |
| wsi_only | 0.5912 ± 0.1003 | [0.467, 0.716] | 0.5853 | 0.2217 | 0.6476 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6269 ± 0.0617 |
| 20% | 0.6254 ± 0.0519 |
| 30% | 0.6209 ± 0.0579 |
| 50% | 0.6112 ± 0.0586 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6375 | 0.6567 | 0.6375 | 20 / 20 | 25 / 70 |
| 1 | 0.6161 | 0.6663 | 0.6161 | 20 / 20 | 24 / 72 |
| 2 | 0.6670 | 0.6824 | 0.6670 | 20 / 20 | 23 / 75 |
| 3 | 0.5307 | 0.5873 | 0.5307 | 20 / 20 | 25 / 71 |
| 4 | 0.6806 | 0.7453 | 0.6806 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6676 ± 0.0566
