# BLCA — 5-fold CV (DSS, selection: val_loss)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5653 ± 0.0702 | [0.478, 0.652] | 0.5564 | 0.1978 | 0.5831 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5058 | 0.6317 | 0.6317 | 1 / 6 | 25 / 70 |
| 1 | 0.5445 | 0.5938 | 0.5938 | 2 / 7 | 24 / 72 |
| 2 | 0.5338 | 0.6844 | 0.6557 | 1 / 6 | 23 / 75 |
| 3 | 0.5562 | 0.5883 | 0.5883 | 1 / 6 | 25 / 71 |
| 4 | 0.6863 | 0.6863 | 0.4604 | 1 / 6 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6369 ± 0.0473
