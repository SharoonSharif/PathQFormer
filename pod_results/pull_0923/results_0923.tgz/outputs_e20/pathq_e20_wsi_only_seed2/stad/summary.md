# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.6030 ± 0.0821 | [0.501, 0.705] | 0.6202 | 0.2107 | 0.6279 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6060 | 0.6987 | 0.6060 | 20 / 20 | 10 / 42 |
| 1 | 0.6028 | 0.6166 | 0.6028 | 20 / 20 | 16 / 56 |
| 2 | 0.7244 | 0.7644 | 0.7244 | 20 / 20 | 16 / 101 |
| 3 | 0.5885 | 0.6538 | 0.5885 | 20 / 20 | 9 / 45 |
| 4 | 0.4933 | 0.5269 | 0.4933 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6521 ± 0.0891
