# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5463 ± 0.1793 | [0.324, 0.769] | 0.5525 | 0.0880 | 0.6537 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8171 | 0.9146 | 0.8171 | 20 / 20 | 5 / 58 |
| 1 | 0.5412 | 0.6471 | 0.5412 | 20 / 20 | 13 / 71 |
| 2 | 0.3365 | 0.7500 | 0.3365 | 20 / 20 | 5 / 45 |
| 3 | 0.5881 | 0.7100 | 0.5881 | 20 / 20 | 9 / 67 |
| 4 | 0.4485 | 0.7697 | 0.4485 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7583 ± 0.0992
