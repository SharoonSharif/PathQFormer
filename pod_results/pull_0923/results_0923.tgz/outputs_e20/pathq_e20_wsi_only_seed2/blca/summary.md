# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5890 ± 0.0988 | [0.466, 0.712] | 0.5883 | 0.2460 | 0.6671 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6500 | 0.6510 | 0.6500 | 20 / 20 | 25 / 70 |
| 1 | 0.6180 | 0.6180 | 0.6180 | 20 / 20 | 24 / 72 |
| 2 | 0.6373 | 0.6598 | 0.6373 | 20 / 20 | 23 / 75 |
| 3 | 0.4136 | 0.5722 | 0.4136 | 20 / 20 | 25 / 71 |
| 4 | 0.6259 | 0.7237 | 0.6259 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6450 ± 0.0559
