# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5859 ± 0.0330 | [0.545, 0.627] | 0.5901 | 0.2430 | 0.5742 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5806 | 0.6226 | 0.5806 | 20 / 20 | 16 / 56 |
| 1 | 0.6092 | 0.6214 | 0.6092 | 20 / 20 | 25 / 69 |
| 2 | 0.5333 | 0.7182 | 0.5333 | 20 / 20 | 18 / 75 |
| 3 | 0.5886 | 0.6276 | 0.5886 | 20 / 20 | 45 / 126 |
| 4 | 0.6177 | 0.6382 | 0.6177 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6456 ± 0.0411
