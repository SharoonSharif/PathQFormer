# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5322 ± 0.1206 | [0.382, 0.682] | 0.5775 | 0.1194 | 0.5594 |
| genomic_only_impute | 0.4799 ± 0.2076 | [0.222, 0.738] | 0.4731 | 0.1454 | 0.4649 |
| rna_permuted | 0.5335 ± 0.1189 | [0.386, 0.681] | 0.5782 | 0.1194 | 0.5591 |
| wsi_only_impute | 0.5337 ± 0.1188 | [0.386, 0.681] | 0.5784 | 0.1194 | 0.5591 |
| wsi_permuted | 0.4868 ± 0.1769 | [0.267, 0.706] | 0.4493 | 0.1173 | 0.4469 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6626 | 0.8780 | 0.6626 | 20 / 20 | 5 / 58 |
| 1 | 0.4549 | 0.6176 | 0.4549 | 20 / 20 | 13 / 71 |
| 2 | 0.6538 | 0.6538 | 0.6538 | 20 / 20 | 5 / 45 |
| 3 | 0.4959 | 0.6883 | 0.4959 | 20 / 20 | 9 / 67 |
| 4 | 0.3939 | 0.7030 | 0.3939 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7082 ± 0.1005
