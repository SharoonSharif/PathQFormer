# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5519 ± 0.1412 | [0.377, 0.727] | 0.5134 | 0.1307 | 0.5515 |
| genomic_only_impute | 0.5138 ± 0.0993 | [0.391, 0.637] | 0.5248 | 0.6061 | 0.5562 |
| rna_permuted | 0.5535 ± 0.1384 | [0.382, 0.725] | 0.5139 | 0.1307 | 0.5530 |
| wsi_only_impute | 0.5520 ± 0.1414 | [0.376, 0.728] | 0.5129 | 0.1307 | 0.5489 |
| wsi_permuted | 0.5402 ± 0.1009 | [0.415, 0.665] | 0.5073 | 0.1549 | 0.5164 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5799 | 0.6615 | 0.5799 | 20 / 20 | 8 / 176 |
| 1 | 0.6444 | 0.7198 | 0.6444 | 20 / 20 | 9 / 168 |
| 2 | 0.5958 | 0.7018 | 0.5958 | 20 / 20 | 20 / 182 |
| 3 | 0.3040 | 0.4471 | 0.3040 | 20 / 20 | 7 / 166 |
| 4 | 0.6356 | 0.8180 | 0.6356 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6696 ± 0.1370
