# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5889 ± 0.1234 | [0.436, 0.742] | 0.5896 | 0.2638 | 0.5510 |
| genomic_only_impute | 0.4625 ± 0.1299 | [0.301, 0.624] | 0.4578 | 0.3878 | 0.4507 |
| rna_permuted | 0.5910 ± 0.1218 | [0.440, 0.742] | 0.5929 | 0.2616 | 0.5571 |
| wsi_only_impute | 0.5899 ± 0.1226 | [0.438, 0.742] | 0.5916 | 0.2607 | 0.5533 |
| wsi_permuted | 0.4420 ± 0.0747 | [0.349, 0.535] | 0.4501 | 0.2748 | 0.4712 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5861 | 0.7185 | 0.5861 | 20 / 20 | 10 / 42 |
| 1 | 0.6079 | 0.7288 | 0.6079 | 20 / 20 | 16 / 56 |
| 2 | 0.7727 | 0.8245 | 0.7727 | 20 / 20 | 16 / 101 |
| 3 | 0.4308 | 0.6577 | 0.4308 | 20 / 20 | 9 / 45 |
| 4 | 0.5470 | 0.6136 | 0.5470 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7086 ± 0.0799
