# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6391 ± 0.1026 | [0.512, 0.766] | 0.6092 | 0.0761 | 0.6742 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4897 | 0.6976 | 0.4897 | 20 / 20 | 8 / 176 |
| 1 | 0.6842 | 0.7582 | 0.6842 | 20 / 20 | 9 / 168 |
| 2 | 0.5858 | 0.6425 | 0.5858 | 20 / 20 | 20 / 182 |
| 3 | 0.7533 | 0.8436 | 0.7533 | 20 / 20 | 7 / 166 |
| 4 | 0.6824 | 0.7022 | 0.6824 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7288 ± 0.0761
