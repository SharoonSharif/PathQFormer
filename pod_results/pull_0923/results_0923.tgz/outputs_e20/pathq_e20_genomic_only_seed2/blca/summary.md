# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5984 ± 0.0788 | [0.501, 0.696] | 0.5967 | 0.1872 | 0.6559 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5106 | 0.5846 | 0.5106 | 20 / 20 | 25 / 70 |
| 1 | 0.5812 | 0.7031 | 0.5812 | 20 / 20 | 24 / 72 |
| 2 | 0.7018 | 0.7182 | 0.7018 | 20 / 20 | 23 / 75 |
| 3 | 0.6544 | 0.6638 | 0.6544 | 20 / 20 | 25 / 71 |
| 4 | 0.5439 | 0.6719 | 0.5439 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6683 ± 0.0518
