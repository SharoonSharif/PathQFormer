# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5927 ± 0.0963 | [0.473, 0.712] | 0.5736 | 0.0789 | 0.6556 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7073 | 0.7317 | 0.7073 | 20 / 20 | 5 / 58 |
| 1 | 0.5784 | 0.7137 | 0.5784 | 20 / 20 | 13 / 71 |
| 2 | 0.5673 | 0.6731 | 0.5673 | 20 / 20 | 5 / 45 |
| 3 | 0.6558 | 0.7425 | 0.6558 | 20 / 20 | 9 / 67 |
| 4 | 0.4545 | 0.7030 | 0.4545 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7128 ± 0.0270
