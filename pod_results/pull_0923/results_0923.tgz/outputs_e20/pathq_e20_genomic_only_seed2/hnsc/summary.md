# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5396 ± 0.0837 | [0.436, 0.644] | 0.5523 | 0.2025 | 0.5265 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5123 | 0.5922 | 0.5123 | 20 / 20 | 16 / 56 |
| 1 | 0.5398 | 0.6729 | 0.5398 | 20 / 20 | 25 / 69 |
| 2 | 0.6223 | 0.6990 | 0.6223 | 20 / 20 | 18 / 75 |
| 3 | 0.6090 | 0.6343 | 0.6090 | 20 / 20 | 45 / 126 |
| 4 | 0.4147 | 0.6826 | 0.4147 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6562 ± 0.0430
