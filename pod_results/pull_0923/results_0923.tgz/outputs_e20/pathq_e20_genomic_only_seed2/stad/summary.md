# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5164 ± 0.1131 | [0.376, 0.657] | 0.5173 | 0.2116 | 0.4889 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4272 | 0.6854 | 0.4272 | 20 / 20 | 10 / 42 |
| 1 | 0.4128 | 0.6615 | 0.4128 | 20 / 20 | 16 / 56 |
| 2 | 0.4806 | 0.5878 | 0.4806 | 20 / 20 | 16 / 101 |
| 3 | 0.6808 | 0.7115 | 0.6808 | 20 / 20 | 9 / 45 |
| 4 | 0.5806 | 0.6741 | 0.5806 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6641 ± 0.0465
