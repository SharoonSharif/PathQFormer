# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5493 ± 0.0259 | [0.517, 0.581] | 0.5524 | 0.0824 | 0.5817 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5112 | 0.6555 | 0.5112 | 20 / 20 | 8 / 176 |
| 1 | 0.5377 | 0.7539 | 0.5377 | 20 / 20 | 9 / 168 |
| 2 | 0.5710 | 0.6715 | 0.5710 | 20 / 20 | 20 / 182 |
| 3 | 0.5529 | 0.7203 | 0.5529 | 20 / 20 | 7 / 166 |
| 4 | 0.5739 | 0.6839 | 0.5739 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6970 ± 0.0398
