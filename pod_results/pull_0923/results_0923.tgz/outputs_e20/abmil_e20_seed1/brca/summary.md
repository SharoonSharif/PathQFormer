# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5729 ± 0.1127 | [0.433, 0.713] | 0.5887 | 0.0761 | 0.6128 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5309 | 0.7302 | 0.5309 | 20 / 20 | 8 / 176 |
| 1 | 0.6657 | 0.7653 | 0.6657 | 20 / 20 | 9 / 168 |
| 2 | 0.5631 | 0.6770 | 0.5631 | 20 / 20 | 20 / 182 |
| 3 | 0.4119 | 0.7555 | 0.4119 | 20 / 20 | 7 / 166 |
| 4 | 0.6931 | 0.7426 | 0.6931 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7341 ± 0.0345
