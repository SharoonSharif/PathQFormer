# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6133 ± 0.0815 | [0.512, 0.715] | 0.5984 | 0.0736 | 0.6460 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4991 | 0.6976 | 0.4991 | 20 / 20 | 8 / 176 |
| 1 | 0.5917 | 0.7696 | 0.5917 | 20 / 20 | 9 / 168 |
| 2 | 0.5982 | 0.6472 | 0.5982 | 20 / 20 | 20 / 182 |
| 3 | 0.7159 | 0.7533 | 0.7159 | 20 / 20 | 7 / 166 |
| 4 | 0.6618 | 0.6999 | 0.6618 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7135 ± 0.0489
