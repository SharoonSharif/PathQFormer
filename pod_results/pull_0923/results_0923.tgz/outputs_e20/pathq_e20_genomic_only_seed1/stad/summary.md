# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5060 ± 0.0560 | [0.436, 0.576] | 0.5137 | 0.2296 | 0.5116 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4536 | 0.7020 | 0.4536 | 20 / 20 | 10 / 42 |
| 1 | 0.5630 | 0.6010 | 0.5630 | 20 / 20 | 16 / 56 |
| 2 | 0.4393 | 0.6031 | 0.4393 | 20 / 20 | 16 / 101 |
| 3 | 0.5269 | 0.6577 | 0.5269 | 20 / 20 | 9 / 45 |
| 4 | 0.5470 | 0.6862 | 0.5470 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6500 ± 0.0466
