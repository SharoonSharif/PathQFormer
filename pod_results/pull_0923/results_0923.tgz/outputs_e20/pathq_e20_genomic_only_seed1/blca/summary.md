# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5954 ± 0.0987 | [0.473, 0.718] | 0.5991 | 0.1814 | 0.6324 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5740 | 0.5846 | 0.5740 | 20 / 20 | 25 / 70 |
| 1 | 0.4691 | 0.6460 | 0.4691 | 20 / 20 | 24 / 72 |
| 2 | 0.7377 | 0.7633 | 0.7377 | 20 / 20 | 23 / 75 |
| 3 | 0.5647 | 0.6043 | 0.5647 | 20 / 20 | 25 / 71 |
| 4 | 0.6317 | 0.6806 | 0.6317 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6558 ± 0.0707
