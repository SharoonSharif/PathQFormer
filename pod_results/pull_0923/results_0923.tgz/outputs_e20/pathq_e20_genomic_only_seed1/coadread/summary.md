# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6360 ± 0.1626 | [0.434, 0.838] | 0.6623 | 0.0742 | 0.6299 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7236 | 0.7927 | 0.7236 | 20 / 20 | 5 / 58 |
| 1 | 0.5078 | 0.7451 | 0.5078 | 20 / 20 | 13 / 71 |
| 2 | 0.4519 | 0.7500 | 0.4519 | 20 / 20 | 5 / 45 |
| 3 | 0.6423 | 0.6585 | 0.6423 | 20 / 20 | 9 / 67 |
| 4 | 0.8545 | 0.8545 | 0.8545 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7602 ± 0.0718
