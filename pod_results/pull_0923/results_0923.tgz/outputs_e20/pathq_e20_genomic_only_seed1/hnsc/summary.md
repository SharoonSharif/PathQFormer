# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5603 ± 0.0365 | [0.515, 0.606] | 0.5781 | 0.1794 | 0.5634 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5689 | 0.6415 | 0.5689 | 20 / 20 | 16 / 56 |
| 1 | 0.5501 | 0.6514 | 0.5501 | 20 / 20 | 25 / 69 |
| 2 | 0.6043 | 0.6437 | 0.6043 | 20 / 20 | 18 / 75 |
| 3 | 0.5729 | 0.5969 | 0.5729 | 20 / 20 | 45 / 126 |
| 4 | 0.5051 | 0.7082 | 0.5051 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6483 ± 0.0397
