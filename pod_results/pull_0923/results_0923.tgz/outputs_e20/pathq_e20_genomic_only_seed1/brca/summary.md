# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5597 ± 0.0746 | [0.467, 0.652] | 0.6058 | 0.0673 | 0.5793 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6478 | 0.6856 | 0.6478 | 20 / 20 | 8 / 176 |
| 1 | 0.5960 | 0.7383 | 0.5960 | 20 / 20 | 9 / 168 |
| 2 | 0.5018 | 0.6802 | 0.5018 | 20 / 20 | 20 / 182 |
| 3 | 0.4648 | 0.6696 | 0.4648 | 20 / 20 | 7 / 166 |
| 4 | 0.5880 | 0.6580 | 0.5880 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6863 ± 0.0309
