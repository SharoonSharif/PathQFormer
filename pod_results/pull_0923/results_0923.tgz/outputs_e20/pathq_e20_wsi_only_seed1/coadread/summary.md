# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5879 ± 0.2067 | [0.331, 0.845] | 0.6144 | 0.0898 | 0.7053 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.9065 | 0.9309 | 0.9065 | 20 / 20 | 5 / 58 |
| 1 | 0.5588 | 0.6843 | 0.5588 | 20 / 20 | 13 / 71 |
| 2 | 0.3846 | 0.8654 | 0.3846 | 20 / 20 | 5 / 45 |
| 3 | 0.6531 | 0.6856 | 0.6531 | 20 / 20 | 9 / 67 |
| 4 | 0.4364 | 0.7879 | 0.4364 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7908 ± 0.1091
