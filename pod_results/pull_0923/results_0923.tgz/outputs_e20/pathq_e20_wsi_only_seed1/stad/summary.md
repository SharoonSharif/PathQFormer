# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5754 ± 0.0854 | [0.469, 0.681] | 0.5758 | 0.1924 | 0.5843 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5199 | 0.6722 | 0.5199 | 20 / 20 | 10 / 42 |
| 1 | 0.6770 | 0.7116 | 0.6770 | 20 / 20 | 16 / 56 |
| 2 | 0.6584 | 0.7032 | 0.6584 | 20 / 20 | 16 / 101 |
| 3 | 0.5269 | 0.6615 | 0.5269 | 20 / 20 | 9 / 45 |
| 4 | 0.4946 | 0.5820 | 0.4946 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6661 ± 0.0514
