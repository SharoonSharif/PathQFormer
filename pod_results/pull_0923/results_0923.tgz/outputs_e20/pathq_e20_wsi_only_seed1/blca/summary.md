# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5942 ± 0.0846 | [0.489, 0.699] | 0.5930 | 0.2336 | 0.6272 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6413 | 0.6817 | 0.6413 | 20 / 20 | 25 / 70 |
| 1 | 0.6035 | 0.6818 | 0.6035 | 20 / 20 | 24 / 72 |
| 2 | 0.6537 | 0.6660 | 0.6537 | 20 / 20 | 23 / 75 |
| 3 | 0.4466 | 0.5279 | 0.4466 | 20 / 20 | 25 / 71 |
| 4 | 0.6259 | 0.7626 | 0.6259 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6640 ± 0.0850
