# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5817 ± 0.0346 | [0.539, 0.625] | 0.5846 | 0.2434 | 0.5753 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5631 | 0.6996 | 0.5631 | 20 / 20 | 16 / 56 |
| 1 | 0.6289 | 0.6317 | 0.6289 | 20 / 20 | 25 / 69 |
| 2 | 0.5366 | 0.6979 | 0.5366 | 20 / 20 | 18 / 75 |
| 3 | 0.5845 | 0.6814 | 0.5845 | 20 / 20 | 45 / 126 |
| 4 | 0.5956 | 0.6280 | 0.5956 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6677 ± 0.0353
