# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.6336 ± 0.1162 | [0.489, 0.778] | 0.6161 | 0.0842 | 0.6551 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5687 | 0.6246 | 0.5687 | 20 / 20 | 8 / 176 |
| 1 | 0.7368 | 0.7994 | 0.7368 | 20 / 20 | 9 / 168 |
| 2 | 0.7050 | 0.7140 | 0.7050 | 20 / 20 | 20 / 182 |
| 3 | 0.4604 | 0.5859 | 0.4604 | 20 / 20 | 7 / 166 |
| 4 | 0.6969 | 0.7281 | 0.6969 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6904 ± 0.0853
