# COADREAD — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6683 ± 0.2424 | [0.367, 0.969] | 0.6825 | 0.0732 | 0.6822 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8740 | nan | nan | -1 / 0 | 5 / 58 |
| 1 | 0.5098 | nan | nan | -1 / 0 | 13 / 71 |
| 2 | 0.3365 | nan | nan | -1 / 0 | 5 / 45 |
| 3 | 0.7182 | nan | nan | -1 / 0 | 9 / 67 |
| 4 | 0.9030 | nan | nan | -1 / 0 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
