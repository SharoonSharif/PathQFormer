# BLCA — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6167 ± 0.0521 | [0.552, 0.681] | 0.6269 | 0.1661 | 0.6772 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6404 | nan | nan | -1 / 0 | 25 / 70 |
| 1 | 0.6006 | nan | nan | -1 / 0 | 24 / 72 |
| 2 | 0.6783 | nan | nan | -1 / 0 | 23 / 75 |
| 3 | 0.5382 | nan | nan | -1 / 0 | 25 / 71 |
| 4 | 0.6259 | nan | nan | -1 / 0 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
