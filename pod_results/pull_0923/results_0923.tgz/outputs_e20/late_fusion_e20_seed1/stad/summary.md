# STAD — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5399 ± 0.0839 | [0.436, 0.644] | 0.5495 | 0.1794 | 0.5391 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4272 | nan | nan | -1 / 0 | 10 / 42 |
| 1 | 0.6598 | nan | nan | -1 / 0 | 16 / 56 |
| 2 | 0.5548 | nan | nan | -1 / 0 | 16 / 101 |
| 3 | 0.5462 | nan | nan | -1 / 0 | 9 / 45 |
| 4 | 0.5114 | nan | nan | -1 / 0 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
