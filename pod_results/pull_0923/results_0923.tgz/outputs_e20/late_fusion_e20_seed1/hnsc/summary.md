# HNSC — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5646 ± 0.0401 | [0.515, 0.614] | 0.5747 | 0.1772 | 0.5675 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5878 | nan | nan | -1 / 0 | 16 / 56 |
| 1 | 0.5801 | nan | nan | -1 / 0 | 25 / 69 |
| 2 | 0.5795 | nan | nan | -1 / 0 | 18 / 75 |
| 3 | 0.5825 | nan | nan | -1 / 0 | 45 / 126 |
| 4 | 0.4932 | nan | nan | -1 / 0 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
