# BRCA — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6197 ± 0.1223 | [0.468, 0.772] | 0.6463 | 0.0659 | 0.6566 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6890 | nan | nan | -1 / 0 | 8 / 176 |
| 1 | 0.7269 | nan | nan | -1 / 0 | 9 / 168 |
| 2 | 0.5947 | nan | nan | -1 / 0 | 20 / 182 |
| 3 | 0.4185 | nan | nan | -1 / 0 | 7 / 166 |
| 4 | 0.6695 | nan | nan | -1 / 0 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
