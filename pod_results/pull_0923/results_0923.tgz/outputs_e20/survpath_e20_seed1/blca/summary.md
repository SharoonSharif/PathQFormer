# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5821 ± 0.0953 | [0.464, 0.700] | 0.5863 | 0.2987 | 0.6456 |
| genomic_only_impute | 0.4655 ± 0.0726 | [0.375, 0.556] | 0.4658 | 0.2216 | 0.5052 |
| rna_permuted | 0.5826 ± 0.0951 | [0.465, 0.701] | 0.5865 | 0.2992 | 0.6448 |
| wsi_only_impute | 0.5822 ± 0.0958 | [0.463, 0.701] | 0.5857 | 0.2990 | 0.6444 |
| wsi_permuted | 0.5278 ± 0.0547 | [0.460, 0.596] | 0.5250 | 0.3389 | 0.5340 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6673 | 0.7365 | 0.6673 | 20 / 20 | 25 / 70 |
| 1 | 0.5890 | 0.6132 | 0.5890 | 20 / 20 | 24 / 72 |
| 2 | 0.6537 | 0.7059 | 0.6537 | 20 / 20 | 23 / 75 |
| 3 | 0.4278 | 0.5637 | 0.4278 | 20 / 20 | 25 / 71 |
| 4 | 0.5727 | 0.6806 | 0.5727 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6600 ± 0.0705
