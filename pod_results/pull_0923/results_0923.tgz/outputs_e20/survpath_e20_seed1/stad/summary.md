# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5944 ± 0.0537 | [0.528, 0.661] | 0.6026 | 0.2401 | 0.5363 |
| genomic_only_impute | 0.4311 ± 0.1411 | [0.256, 0.606] | 0.4258 | 0.2314 | 0.5509 |
| rna_permuted | 0.5907 ± 0.0557 | [0.522, 0.660] | 0.5998 | 0.2402 | 0.5338 |
| wsi_only_impute | 0.5940 ± 0.0546 | [0.526, 0.662] | 0.6022 | 0.2400 | 0.5356 |
| wsi_permuted | 0.4603 ± 0.0795 | [0.362, 0.559] | 0.4569 | 0.2676 | 0.4290 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5563 | 0.6490 | 0.5563 | 20 / 20 | 10 / 42 |
| 1 | 0.6788 | 0.6943 | 0.6788 | 20 / 20 | 16 / 56 |
| 2 | 0.6172 | 0.7138 | 0.6172 | 20 / 20 | 16 / 101 |
| 3 | 0.5654 | 0.6962 | 0.5654 | 20 / 20 | 9 / 45 |
| 4 | 0.5544 | 0.5840 | 0.5544 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6674 ± 0.0524
