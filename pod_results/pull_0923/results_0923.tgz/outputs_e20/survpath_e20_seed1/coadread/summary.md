# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5687 ± 0.1243 | [0.414, 0.723] | 0.5831 | 0.1090 | 0.5610 |
| genomic_only_impute | 0.4801 ± 0.2265 | [0.199, 0.761] | 0.4792 | 0.1004 | 0.5273 |
| rna_permuted | 0.5730 ± 0.1240 | [0.419, 0.727] | 0.5884 | 0.1090 | 0.5674 |
| wsi_only_impute | 0.5736 ± 0.1237 | [0.420, 0.727] | 0.5898 | 0.1090 | 0.5694 |
| wsi_permuted | 0.5083 ± 0.0549 | [0.440, 0.576] | 0.5189 | 0.1036 | 0.5453 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7764 | 0.8455 | 0.7764 | 20 / 20 | 5 / 58 |
| 1 | 0.5529 | 0.6431 | 0.5529 | 20 / 20 | 13 / 71 |
| 2 | 0.5577 | 0.6346 | 0.5577 | 20 / 20 | 5 / 45 |
| 3 | 0.4472 | 0.6233 | 0.4472 | 20 / 20 | 9 / 67 |
| 4 | 0.5091 | 0.6667 | 0.5091 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6827 ± 0.0924
