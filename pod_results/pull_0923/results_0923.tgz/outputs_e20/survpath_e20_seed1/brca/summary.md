# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5513 ± 0.1434 | [0.373, 0.729] | 0.5792 | 0.1268 | 0.5437 |
| genomic_only_impute | 0.4983 ± 0.0946 | [0.381, 0.616] | 0.5322 | 0.4926 | 0.5195 |
| rna_permuted | 0.5525 ± 0.1437 | [0.374, 0.731] | 0.5801 | 0.1268 | 0.5447 |
| wsi_only_impute | 0.5507 ± 0.1433 | [0.373, 0.729] | 0.5793 | 0.1268 | 0.5455 |
| wsi_permuted | 0.5792 ± 0.1391 | [0.406, 0.752] | 0.4857 | 0.1783 | 0.4554 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5756 | 0.6168 | 0.5756 | 20 / 20 | 8 / 176 |
| 1 | 0.6757 | 0.7681 | 0.6757 | 20 / 20 | 9 / 168 |
| 2 | 0.5612 | 0.7298 | 0.5612 | 20 / 20 | 20 / 182 |
| 3 | 0.3084 | 0.7621 | 0.3084 | 20 / 20 | 7 / 166 |
| 4 | 0.6356 | 0.8370 | 0.6356 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7428 ± 0.0805
