# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5724 ± 0.1060 | [0.441, 0.704] | 0.5430 | 0.0778 | 0.5953 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5043 | 0.8230 | 0.5043 | 20 / 20 | 8 / 176 |
| 1 | 0.4488 | 0.6863 | 0.4488 | 20 / 20 | 9 / 168 |
| 2 | 0.5810 | 0.6298 | 0.5810 | 20 / 20 | 20 / 182 |
| 3 | 0.7280 | 0.8833 | 0.7280 | 20 / 20 | 7 / 166 |
| 4 | 0.5998 | 0.6485 | 0.5998 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7342 ± 0.1125
