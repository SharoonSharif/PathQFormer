# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5554 ± 0.0609 | [0.480, 0.631] | 0.5648 | 0.3379 | 0.5663 |
| genomic_only_impute | 0.4922 ± 0.0830 | [0.389, 0.595] | 0.4912 | 0.3928 | 0.5043 |
| rna_permuted | 0.5542 ± 0.0610 | [0.478, 0.630] | 0.5651 | 0.3377 | 0.5680 |
| wsi_only_impute | 0.5598 ± 0.0611 | [0.484, 0.636] | 0.5682 | 0.3368 | 0.5673 |
| wsi_permuted | 0.4883 ± 0.1105 | [0.351, 0.625] | 0.4841 | 0.3465 | 0.5026 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4804 | 0.6110 | 0.4804 | 20 / 20 | 16 / 56 |
| 1 | 0.5567 | 0.6242 | 0.5567 | 20 / 20 | 25 / 69 |
| 2 | 0.5479 | 0.6302 | 0.5479 | 20 / 20 | 18 / 75 |
| 3 | 0.5420 | 0.5997 | 0.5420 | 20 / 20 | 45 / 126 |
| 4 | 0.6502 | 0.6980 | 0.6502 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6326 ± 0.0384
