# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5058 ± 0.1631 | [0.303, 0.708] | 0.4839 | 0.1359 | 0.4818 |
| genomic_only_impute | 0.5477 ± 0.0780 | [0.451, 0.645] | 0.4949 | 0.3474 | 0.5400 |
| rna_permuted | 0.5048 ± 0.1622 | [0.303, 0.706] | 0.4831 | 0.1359 | 0.4812 |
| wsi_only_impute | 0.5050 ± 0.1624 | [0.303, 0.707] | 0.4831 | 0.1359 | 0.4816 |
| wsi_permuted | 0.4762 ± 0.0489 | [0.415, 0.537] | 0.4498 | 0.1611 | 0.4804 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4261 | 0.6924 | 0.4261 | 20 / 20 | 8 / 176 |
| 1 | 0.6927 | 0.8051 | 0.6927 | 20 / 20 | 9 / 168 |
| 2 | 0.6077 | 0.7008 | 0.6077 | 20 / 20 | 20 / 182 |
| 3 | 0.2731 | 0.5771 | 0.2731 | 20 / 20 | 7 / 166 |
| 4 | 0.5293 | 0.7944 | 0.5293 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7140 ± 0.0924
