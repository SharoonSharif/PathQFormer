# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5787 ± 0.0613 | [0.503, 0.655] | 0.5799 | 0.3230 | 0.5036 |
| genomic_only_impute | 0.5854 ± 0.0643 | [0.506, 0.665] | 0.5843 | 0.2026 | 0.4877 |
| rna_permuted | 0.5797 ± 0.0608 | [0.504, 0.655] | 0.5807 | 0.3228 | 0.5053 |
| wsi_only_impute | 0.5803 ± 0.0613 | [0.504, 0.656] | 0.5812 | 0.3230 | 0.5039 |
| wsi_permuted | 0.4732 ± 0.1266 | [0.316, 0.630] | 0.4987 | 0.3224 | 0.5254 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6026 | 0.6722 | 0.6026 | 20 / 20 | 10 / 42 |
| 1 | 0.6356 | 0.6960 | 0.6356 | 20 / 20 | 16 / 56 |
| 2 | 0.6278 | 0.7279 | 0.6278 | 20 / 20 | 16 / 101 |
| 3 | 0.5000 | 0.6538 | 0.5000 | 20 / 20 | 9 / 45 |
| 4 | 0.5276 | 0.5766 | 0.5276 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6653 ± 0.0568
