# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6079 ± 0.1612 | [0.408, 0.808] | 0.6151 | 0.1021 | 0.5194 |
| genomic_only_impute | 0.4599 ± 0.1771 | [0.240, 0.680] | 0.4540 | 0.0711 | 0.5872 |
| rna_permuted | 0.6086 ± 0.1602 | [0.410, 0.807] | 0.6172 | 0.1021 | 0.5183 |
| wsi_only_impute | 0.6080 ± 0.1609 | [0.408, 0.808] | 0.6157 | 0.1021 | 0.5204 |
| wsi_permuted | 0.5347 ± 0.0479 | [0.475, 0.594] | 0.5518 | 0.1007 | 0.5934 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8862 | 0.9106 | 0.8862 | 20 / 20 | 5 / 58 |
| 1 | 0.5951 | 0.6333 | 0.5951 | 20 / 20 | 13 / 71 |
| 2 | 0.5096 | 0.6442 | 0.5096 | 20 / 20 | 5 / 45 |
| 3 | 0.4878 | 0.5989 | 0.4878 | 20 / 20 | 9 / 67 |
| 4 | 0.5606 | 0.8182 | 0.5606 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7210 ± 0.1359
