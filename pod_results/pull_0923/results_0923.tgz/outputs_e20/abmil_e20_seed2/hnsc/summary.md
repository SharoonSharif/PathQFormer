# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5319 ± 0.0672 | [0.448, 0.615] | 0.5275 | 0.2160 | 0.5750 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5181 | 0.6009 | 0.5181 | 20 / 20 | 16 / 56 |
| 1 | 0.6111 | 0.6495 | 0.6111 | 20 / 20 | 25 / 69 |
| 2 | 0.4464 | 0.5592 | 0.4464 | 20 / 20 | 18 / 75 |
| 3 | 0.4967 | 0.5706 | 0.4967 | 20 / 20 | 45 / 126 |
| 4 | 0.5870 | 0.6212 | 0.5870 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6003 ± 0.0368
