# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5794 ± 0.1312 | [0.417, 0.742] | 0.6126 | 0.0759 | 0.6181 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6375 | 0.7070 | 0.6375 | 20 / 20 | 8 / 176 |
| 1 | 0.6529 | 0.7553 | 0.6529 | 20 / 20 | 9 / 168 |
| 2 | 0.5826 | 0.7071 | 0.5826 | 20 / 20 | 20 / 182 |
| 3 | 0.3524 | 0.4559 | 0.3524 | 20 / 20 | 7 / 166 |
| 4 | 0.6717 | 0.7471 | 0.6717 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6745 ± 0.1242
