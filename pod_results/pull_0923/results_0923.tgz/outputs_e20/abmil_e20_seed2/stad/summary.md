# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5393 ± 0.0724 | [0.449, 0.629] | 0.5461 | 0.2233 | 0.5299 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6325 | 0.6589 | 0.6325 | 20 / 20 | 10 / 42 |
| 1 | 0.4663 | 0.5786 | 0.4663 | 20 / 20 | 16 / 56 |
| 2 | 0.5995 | 0.6561 | 0.5995 | 20 / 20 | 16 / 101 |
| 3 | 0.4923 | 0.6538 | 0.4923 | 20 / 20 | 9 / 45 |
| 4 | 0.5060 | 0.6122 | 0.5060 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6319 ± 0.0354
