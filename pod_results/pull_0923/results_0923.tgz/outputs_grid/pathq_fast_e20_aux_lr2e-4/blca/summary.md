# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6148 ± 0.1012 | [0.489, 0.740] | 0.6066 | 0.1941 | 0.6491 |
| genomic_only | 0.5889 ± 0.1122 | [0.450, 0.728] | 0.5870 | 0.1806 | 0.6328 |
| wsi_only | 0.5598 ± 0.0956 | [0.441, 0.678] | 0.5401 | 0.2358 | 0.5900 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6190 ± 0.1029 |
| 20% | 0.6099 ± 0.0939 |
| 30% | 0.6017 ± 0.0941 |
| 50% | 0.5882 ± 0.0880 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5971 | 0.6317 | 0.5971 | 20 / 20 | 25 / 70 |
| 1 | 0.6238 | 0.6828 | 0.6238 | 20 / 20 | 24 / 72 |
| 2 | 0.7141 | 0.7357 | 0.7141 | 20 / 20 | 23 / 75 |
| 3 | 0.4542 | 0.5788 | 0.4542 | 20 / 20 | 25 / 71 |
| 4 | 0.6849 | 0.7755 | 0.6849 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6809 ± 0.0787
