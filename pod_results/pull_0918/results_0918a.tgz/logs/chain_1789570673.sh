#!/usr/bin/env bash
until grep -qE "\[batch6\].*done" "/workspace/logs/pod_chained_042233.out" 2>/dev/null; do sleep 60; done
echo "[chain] $(date '+%F %T') marker found in /workspace/logs/pod_chained_042233.out"
[ -f "/usr/bin/runpodctl.real" ] && mv -f "/usr/bin/runpodctl.real" "/usr/bin/runpodctl" && echo "[chain] restored runpodctl"
cd "/workspace/PathQFormer_pr/PathQFormer" && setsid bash scripts/pod/batch7.sh  > /workspace/logs/pod_chained_$(date +%H%M%S).out 2>&1 < /dev/null &
echo "[chain] launched: bash scripts/pod/batch7.sh "
