# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5223 ± 0.2334 | [0.233, 0.812] | 0.5615 | 0.1261 | 0.5576 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4347 | 0.6907 | 0.4347 | 10 / 10 | 8 / 176 |
| 1 | 0.6202 | 0.7155 | 0.6202 | 10 / 10 | 9 / 168 |
| 2 | 0.6449 | 0.6596 | 0.6449 | 10 / 10 | 20 / 182 |
| 3 | 0.1586 | 0.3502 | 0.1586 | 10 / 10 | 7 / 166 |
| 4 | 0.7532 | 0.7845 | 0.7532 | 10 / 10 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6401 ± 0.1684
