# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5880 ± 0.1351 | [0.420, 0.756] | 0.5487 | 0.0742 | 0.6129 |
| genomic_only | 0.5683 ± 0.0618 | [0.492, 0.645] | 0.5078 | 0.0673 | 0.5824 |
| wsi_only | 0.5911 ± 0.1185 | [0.444, 0.738] | 0.5632 | 0.0764 | 0.5802 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5731 ± 0.1282 |
| 20% | 0.5615 ± 0.1182 |
| 30% | 0.5682 ± 0.1032 |
| 50% | 0.5918 ± 0.0864 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5241 | 0.5584 | 0.5241 | 10 / 10 | 8 / 176 |
| 1 | 0.7169 | 0.7169 | 0.7169 | 10 / 10 | 9 / 168 |
| 2 | 0.6818 | 0.6945 | 0.6818 | 10 / 10 | 20 / 182 |
| 3 | 0.3844 | 0.5088 | 0.3844 | 10 / 10 | 7 / 166 |
| 4 | 0.6329 | 0.6500 | 0.6329 | 10 / 10 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6257 ± 0.0892
