# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5858 ± 0.1069 | [0.453, 0.718] | 0.5817 | 0.1981 | 0.6122 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5704 | 0.6255 | 0.5704 | 20 / 20 | 16 / 56 |
| 1 | 0.6485 | 0.6767 | 0.6485 | 20 / 20 | 25 / 69 |
| 2 | 0.4245 | 0.6528 | 0.4245 | 20 / 20 | 18 / 75 |
| 3 | 0.5755 | 0.5775 | 0.5755 | 20 / 20 | 45 / 126 |
| 4 | 0.7099 | 0.7338 | 0.7099 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6533 ± 0.0582
