# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5756 ± 0.0502 | [0.513, 0.638] | 0.5957 | 0.1992 | 0.5357 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5464 | 0.6656 | 0.5464 | 20 / 20 | 10 / 42 |
| 1 | 0.5561 | 0.5769 | 0.5561 | 20 / 20 | 16 / 56 |
| 2 | 0.6620 | 0.7102 | 0.6620 | 20 / 20 | 16 / 101 |
| 3 | 0.5385 | 0.5769 | 0.5385 | 20 / 20 | 9 / 45 |
| 4 | 0.5753 | 0.6237 | 0.5753 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6306 ± 0.0578
