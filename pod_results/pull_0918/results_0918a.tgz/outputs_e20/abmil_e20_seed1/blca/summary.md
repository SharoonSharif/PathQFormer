# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5582 ± 0.1161 | [0.414, 0.702] | 0.5458 | 0.2094 | 0.6306 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6683 | 0.6683 | 0.6683 | 20 / 20 | 25 / 70 |
| 1 | 0.6586 | 0.6760 | 0.6586 | 20 / 20 | 24 / 72 |
| 2 | 0.5943 | 0.6844 | 0.5943 | 20 / 20 | 23 / 75 |
| 3 | 0.4297 | 0.5288 | 0.4297 | 20 / 20 | 25 / 71 |
| 4 | 0.4403 | 0.6504 | 0.4403 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6416 ± 0.0643
