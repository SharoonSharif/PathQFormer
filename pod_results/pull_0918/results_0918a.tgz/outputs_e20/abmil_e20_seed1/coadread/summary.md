# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.6051 ± 0.1700 | [0.394, 0.816] | 0.6346 | 0.0961 | 0.6663 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7967 | 0.8537 | 0.7967 | 20 / 20 | 5 / 58 |
| 1 | 0.5539 | 0.6235 | 0.5539 | 20 / 20 | 13 / 71 |
| 2 | 0.7692 | 0.8077 | 0.7692 | 20 / 20 | 5 / 45 |
| 3 | 0.4146 | 0.7019 | 0.4146 | 20 / 20 | 9 / 67 |
| 4 | 0.4909 | 0.6545 | 0.4909 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7283 ± 0.0989
