# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6057 ± 0.0987 | [0.483, 0.728] | 0.6048 | 0.2365 | 0.6536 |
| genomic_only_impute | 0.5088 ± 0.0419 | [0.457, 0.561] | 0.5009 | 0.2873 | 0.4946 |
| wsi_only_impute | 0.6076 ± 0.1011 | [0.482, 0.733] | 0.6056 | 0.2363 | 0.6534 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7087 | 0.7317 | 0.7087 | 20 / 20 | 25 / 70 |
| 1 | 0.6335 | 0.6364 | 0.6335 | 20 / 20 | 24 / 72 |
| 2 | 0.6578 | 0.6906 | 0.6578 | 20 / 20 | 23 / 75 |
| 3 | 0.4504 | 0.5449 | 0.4504 | 20 / 20 | 25 / 71 |
| 4 | 0.5784 | 0.7122 | 0.5784 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6632 ± 0.0751
