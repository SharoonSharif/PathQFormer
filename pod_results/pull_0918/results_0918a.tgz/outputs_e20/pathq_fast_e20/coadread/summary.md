# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6511 ± 0.1402 | [0.477, 0.825] | 0.6525 | 0.0771 | 0.7497 |
| genomic_only | 0.6507 ± 0.1819 | [0.425, 0.877] | 0.6448 | 0.0815 | 0.6592 |
| genomic_only_impute | 0.6004 ± 0.1450 | [0.420, 0.781] | 0.5627 | 0.0746 | 0.6722 |
| wsi_only | 0.6376 ± 0.0842 | [0.533, 0.742] | 0.6296 | 0.0812 | 0.6857 |
| wsi_only_impute | 0.6312 ± 0.1043 | [0.502, 0.761] | 0.6366 | 0.0693 | 0.7080 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6422 ± 0.1431 |
| 20% | 0.6497 ± 0.1204 |
| 30% | 0.6500 ± 0.1261 |
| 50% | 0.6193 ± 0.1237 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8415 | 0.8902 | 0.8415 | 20 / 20 | 5 / 58 |
| 1 | 0.6725 | 0.6863 | 0.6725 | 20 / 20 | 13 / 71 |
| 2 | 0.4519 | 0.9038 | 0.4519 | 20 / 20 | 5 / 45 |
| 3 | 0.6775 | 0.7913 | 0.6775 | 20 / 20 | 9 / 67 |
| 4 | 0.6121 | 0.7455 | 0.6121 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.8034 ± 0.0933
