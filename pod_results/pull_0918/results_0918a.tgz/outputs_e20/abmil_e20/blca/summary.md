# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5777 ± 0.1068 | [0.445, 0.710] | 0.5738 | 0.1988 | 0.6354 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6029 | 0.6442 | 0.6029 | 20 / 20 | 25 / 70 |
| 1 | 0.5696 | 0.6219 | 0.5696 | 20 / 20 | 24 / 72 |
| 2 | 0.7428 | 0.7428 | 0.7428 | 20 / 20 | 23 / 75 |
| 3 | 0.5099 | 0.6440 | 0.5099 | 20 / 20 | 25 / 71 |
| 4 | 0.4633 | 0.6878 | 0.4633 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6681 ± 0.0481
