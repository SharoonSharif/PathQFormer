# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5425 ± 0.0563 | [0.473, 0.612] | 0.5439 | 0.2025 | 0.5613 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5497 | 0.6887 | 0.5497 | 20 / 20 | 10 / 42 |
| 1 | 0.5199 | 0.5717 | 0.5199 | 20 / 20 | 16 / 56 |
| 2 | 0.6278 | 0.7220 | 0.6278 | 20 / 20 | 16 / 101 |
| 3 | 0.4731 | 0.6077 | 0.4731 | 20 / 20 | 9 / 45 |
| 4 | 0.5423 | 0.6216 | 0.5423 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6424 ± 0.0615
