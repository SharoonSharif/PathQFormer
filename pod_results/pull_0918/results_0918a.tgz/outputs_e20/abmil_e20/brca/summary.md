# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5737 ± 0.1833 | [0.346, 0.801] | 0.5952 | 0.0797 | 0.6098 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5361 | 0.5825 | 0.5361 | 20 / 20 | 8 / 176 |
| 1 | 0.7354 | 0.8023 | 0.7354 | 20 / 20 | 9 / 168 |
| 2 | 0.6834 | 0.7037 | 0.6834 | 20 / 20 | 20 / 182 |
| 3 | 0.2731 | 0.4449 | 0.2731 | 20 / 20 | 7 / 166 |
| 4 | 0.6405 | 0.6931 | 0.6405 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6453 ± 0.1364
