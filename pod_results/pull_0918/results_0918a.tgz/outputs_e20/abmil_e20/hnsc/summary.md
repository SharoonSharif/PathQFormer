# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5699 ± 0.0608 | [0.494, 0.645] | 0.5792 | 0.2007 | 0.6049 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5907 | 0.6255 | 0.5907 | 20 / 20 | 16 / 56 |
| 1 | 0.6162 | 0.6467 | 0.6162 | 20 / 20 | 25 / 69 |
| 2 | 0.5130 | 0.5795 | 0.5130 | 20 / 20 | 18 / 75 |
| 3 | 0.4980 | 0.5435 | 0.4980 | 20 / 20 | 45 / 126 |
| 4 | 0.6314 | 0.6399 | 0.6314 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6070 ± 0.0441
