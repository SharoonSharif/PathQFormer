# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5952 ± 0.1741 | [0.379, 0.811] | 0.6402 | 0.0961 | 0.6281 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8089 | 0.8333 | 0.8089 | 20 / 20 | 5 / 58 |
| 1 | 0.4598 | 0.6000 | 0.4598 | 20 / 20 | 13 / 71 |
| 2 | 0.7596 | 0.8702 | 0.7596 | 20 / 20 | 5 / 45 |
| 3 | 0.4932 | 0.6477 | 0.4932 | 20 / 20 | 9 / 67 |
| 4 | 0.4545 | 0.6545 | 0.4545 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7212 ± 0.1218
