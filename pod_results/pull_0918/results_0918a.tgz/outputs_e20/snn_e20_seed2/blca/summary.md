# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5806 ± 0.0984 | [0.458, 0.703] | 0.5764 | 0.2361 | 0.6518 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5731 | 0.6288 | 0.5731 | 20 / 20 | 25 / 70 |
| 1 | 0.5169 | 0.7244 | 0.5169 | 20 / 20 | 24 / 72 |
| 2 | 0.7515 | 0.7577 | 0.7515 | 20 / 20 | 23 / 75 |
| 3 | 0.5156 | 0.6289 | 0.5156 | 20 / 20 | 25 / 71 |
| 4 | 0.5460 | 0.6633 | 0.5460 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6806 ± 0.0581
