# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5407 ± 0.0786 | [0.443, 0.638] | 0.5496 | 0.2183 | 0.5547 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4782 | 0.6067 | 0.4782 | 20 / 20 | 16 / 56 |
| 1 | 0.5534 | 0.6354 | 0.5534 | 20 / 20 | 25 / 69 |
| 2 | 0.6719 | 0.7384 | 0.6719 | 20 / 20 | 18 / 75 |
| 3 | 0.5077 | 0.6389 | 0.5077 | 20 / 20 | 45 / 126 |
| 4 | 0.4923 | 0.5188 | 0.4923 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6276 ± 0.0787
