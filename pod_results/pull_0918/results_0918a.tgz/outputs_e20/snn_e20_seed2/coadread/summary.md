# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5753 ± 0.1898 | [0.340, 0.811] | 0.5786 | 0.0887 | 0.6352 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7947 | 0.8862 | 0.7947 | 20 / 20 | 5 / 58 |
| 1 | 0.5892 | 0.6451 | 0.5892 | 20 / 20 | 13 / 71 |
| 2 | 0.2740 | 0.7212 | 0.2740 | 20 / 20 | 5 / 45 |
| 3 | 0.5732 | 0.6924 | 0.5732 | 20 / 20 | 9 / 67 |
| 4 | 0.6455 | 0.7818 | 0.6455 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7453 ± 0.0930
