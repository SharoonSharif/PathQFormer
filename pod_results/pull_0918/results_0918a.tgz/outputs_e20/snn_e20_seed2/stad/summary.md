# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5509 ± 0.0908 | [0.438, 0.664] | 0.5648 | 0.2323 | 0.5264 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4884 | 0.5315 | 0.4884 | 20 / 20 | 10 / 42 |
| 1 | 0.4499 | 0.5225 | 0.4499 | 20 / 20 | 16 / 56 |
| 2 | 0.5412 | 0.5819 | 0.5412 | 20 / 20 | 16 / 101 |
| 3 | 0.6808 | 0.7000 | 0.6808 | 20 / 20 | 9 / 45 |
| 4 | 0.5944 | 0.6310 | 0.5944 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5934 ± 0.0738
