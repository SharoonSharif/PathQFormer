# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5902 ± 0.0857 | [0.484, 0.697] | 0.5870 | 0.2248 | 0.6495 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5500 | 0.6692 | 0.5500 | 20 / 20 | 25 / 70 |
| 1 | 0.5513 | 0.6828 | 0.5513 | 20 / 20 | 24 / 72 |
| 2 | 0.7392 | 0.7664 | 0.7392 | 20 / 20 | 23 / 75 |
| 3 | 0.5269 | 0.5751 | 0.5269 | 20 / 20 | 25 / 71 |
| 4 | 0.5835 | 0.6806 | 0.5835 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6748 ± 0.0679
