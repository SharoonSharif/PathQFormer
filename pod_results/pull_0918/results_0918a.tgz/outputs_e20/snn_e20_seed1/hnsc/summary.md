# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5280 ± 0.0799 | [0.429, 0.627] | 0.5345 | 0.2161 | 0.5245 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4717 | 0.6081 | 0.4717 | 20 / 20 | 16 / 56 |
| 1 | 0.5258 | 0.5904 | 0.5258 | 20 / 20 | 25 / 69 |
| 2 | 0.6584 | 0.7503 | 0.6584 | 20 / 20 | 18 / 75 |
| 3 | 0.5292 | 0.5572 | 0.5292 | 20 / 20 | 45 / 126 |
| 4 | 0.4548 | 0.6024 | 0.4548 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6217 ± 0.0746
