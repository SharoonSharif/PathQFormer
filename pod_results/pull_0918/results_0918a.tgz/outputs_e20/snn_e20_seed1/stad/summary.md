# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5384 ± 0.0821 | [0.436, 0.640] | 0.5491 | 0.2422 | 0.5168 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4934 | 0.6987 | 0.4934 | 20 / 20 | 10 / 42 |
| 1 | 0.4646 | 0.5570 | 0.4646 | 20 / 20 | 16 / 56 |
| 2 | 0.5112 | 0.6879 | 0.5112 | 20 / 20 | 16 / 101 |
| 3 | 0.6750 | 0.6750 | 0.6750 | 20 / 20 | 9 / 45 |
| 4 | 0.5481 | 0.6025 | 0.5481 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6442 ± 0.0616
