# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5986 ± 0.1968 | [0.354, 0.843] | 0.5969 | 0.0868 | 0.6949 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7805 | 0.8780 | 0.7805 | 20 / 20 | 5 / 58 |
| 1 | 0.5980 | 0.6069 | 0.5980 | 20 / 20 | 13 / 71 |
| 2 | 0.2788 | 0.5769 | 0.2788 | 20 / 20 | 5 / 45 |
| 3 | 0.7385 | 0.7385 | 0.7385 | 20 / 20 | 9 / 67 |
| 4 | 0.5970 | 0.6636 | 0.5970 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6928 ± 0.1205
