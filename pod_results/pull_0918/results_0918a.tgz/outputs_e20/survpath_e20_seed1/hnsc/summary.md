# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5678 ± 0.0864 | [0.461, 0.675] | 0.5776 | 0.2557 | 0.5778 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4615 | 0.6125 | 0.4615 | 20 / 20 | 16 / 56 |
| 1 | 0.6139 | 0.6504 | 0.6139 | 20 / 20 | 25 / 69 |
| 2 | 0.5750 | 0.6753 | 0.5750 | 20 / 20 | 18 / 75 |
| 3 | 0.5077 | 0.5639 | 0.5077 | 20 / 20 | 45 / 126 |
| 4 | 0.6809 | 0.6826 | 0.6809 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6369 ± 0.0492
