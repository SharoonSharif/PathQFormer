# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5687 ± 0.1243 | [0.414, 0.723] | 0.5831 | 0.1090 | 0.5610 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7764 | 0.8455 | 0.7764 | 20 / 20 | 5 / 58 |
| 1 | 0.5529 | 0.6431 | 0.5529 | 20 / 20 | 13 / 71 |
| 2 | 0.5577 | 0.6346 | 0.5577 | 20 / 20 | 5 / 45 |
| 3 | 0.4472 | 0.6233 | 0.4472 | 20 / 20 | 9 / 67 |
| 4 | 0.5091 | 0.6667 | 0.5091 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6827 ± 0.0924
