# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5513 ± 0.1434 | [0.373, 0.729] | 0.5792 | 0.1268 | 0.5437 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5756 | 0.6168 | 0.5756 | 20 / 20 | 8 / 176 |
| 1 | 0.6757 | 0.7681 | 0.6757 | 20 / 20 | 9 / 168 |
| 2 | 0.5612 | 0.7298 | 0.5612 | 20 / 20 | 20 / 182 |
| 3 | 0.3084 | 0.7621 | 0.3084 | 20 / 20 | 7 / 166 |
| 4 | 0.6356 | 0.8370 | 0.6356 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7428 ± 0.0805
