# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6602 ± 0.1506 | [0.473, 0.847] | 0.6449 | 0.0839 | 0.7757 |
| genomic_only | 0.6115 ± 0.0874 | [0.503, 0.720] | 0.6103 | 0.0745 | 0.6239 |
| wsi_only | 0.6570 ± 0.1602 | [0.458, 0.856] | 0.6313 | 0.0876 | 0.7357 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6681 ± 0.1516 |
| 20% | 0.6457 ± 0.1428 |
| 30% | 0.6406 ± 0.1429 |
| 50% | 0.6529 ± 0.1048 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8943 | 0.9106 | 0.8943 | 20 / 20 | 5 / 58 |
| 1 | 0.6569 | 0.6784 | 0.6569 | 20 / 20 | 13 / 71 |
| 2 | 0.5673 | 0.8654 | 0.5673 | 20 / 20 | 5 / 45 |
| 3 | 0.6856 | 0.6924 | 0.6856 | 20 / 20 | 9 / 67 |
| 4 | 0.4970 | 0.7030 | 0.4970 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7700 ± 0.1093
