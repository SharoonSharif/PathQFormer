# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5607 ± 0.0380 | [0.514, 0.608] | 0.5730 | 0.2021 | 0.5956 |
| genomic_only | 0.5380 ± 0.0699 | [0.451, 0.625] | 0.5578 | 0.1990 | 0.5611 |
| wsi_only | 0.5815 ± 0.0280 | [0.547, 0.616] | 0.5894 | 0.1998 | 0.5970 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5562 ± 0.0342 |
| 20% | 0.5619 ± 0.0273 |
| 30% | 0.5518 ± 0.0287 |
| 50% | 0.5496 ± 0.0177 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5356 | 0.6270 | 0.5356 | 20 / 20 | 16 / 56 |
| 1 | 0.6176 | 0.6242 | 0.6176 | 20 / 20 | 25 / 69 |
| 2 | 0.5660 | 0.7080 | 0.5660 | 20 / 20 | 18 / 75 |
| 3 | 0.5179 | 0.6360 | 0.5179 | 20 / 20 | 45 / 126 |
| 4 | 0.5666 | 0.6041 | 0.5666 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6399 ± 0.0398
