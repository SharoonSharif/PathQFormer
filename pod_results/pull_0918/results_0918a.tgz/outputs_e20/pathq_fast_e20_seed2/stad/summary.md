# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6088 ± 0.1033 | [0.480, 0.737] | 0.6173 | 0.1795 | 0.6331 |
| genomic_only | 0.5614 ± 0.0683 | [0.477, 0.646] | 0.5723 | 0.2072 | 0.5562 |
| wsi_only | 0.6139 ± 0.1103 | [0.477, 0.751] | 0.6142 | 0.1739 | 0.6703 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6069 ± 0.1038 |
| 20% | 0.5900 ± 0.0857 |
| 30% | 0.5989 ± 0.0792 |
| 50% | 0.5885 ± 0.0725 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5199 | 0.5828 | 0.5199 | 20 / 20 | 10 / 42 |
| 1 | 0.5959 | 0.6632 | 0.5959 | 20 / 20 | 16 / 56 |
| 2 | 0.7715 | 0.7998 | 0.7715 | 20 / 20 | 16 / 101 |
| 3 | 0.6346 | 0.6885 | 0.6346 | 20 / 20 | 9 / 45 |
| 4 | 0.5222 | 0.5806 | 0.5222 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6630 ± 0.0902
