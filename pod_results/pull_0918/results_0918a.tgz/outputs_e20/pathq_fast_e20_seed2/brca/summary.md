# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6189 ± 0.1116 | [0.480, 0.757] | 0.6449 | 0.0781 | 0.6569 |
| genomic_only | 0.5720 ± 0.1098 | [0.436, 0.708] | 0.5906 | 0.0675 | 0.6232 |
| wsi_only | 0.5832 ± 0.1648 | [0.379, 0.788] | 0.6059 | 0.0786 | 0.5954 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6223 ± 0.0942 |
| 20% | 0.6126 ± 0.0881 |
| 30% | 0.6099 ± 0.0921 |
| 50% | 0.5854 ± 0.0907 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5601 | 0.6770 | 0.5601 | 20 / 20 | 8 / 176 |
| 1 | 0.7653 | 0.7710 | 0.7653 | 20 / 20 | 9 / 168 |
| 2 | 0.5055 | 0.7032 | 0.5055 | 20 / 20 | 20 / 182 |
| 3 | 0.5551 | 0.5980 | 0.5551 | 20 / 20 | 7 / 166 |
| 4 | 0.7083 | 0.7186 | 0.7083 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6935 ± 0.0635
