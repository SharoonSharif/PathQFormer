# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5554 ± 0.0609 | [0.480, 0.631] | 0.5648 | 0.3379 | 0.5663 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4804 | 0.6110 | 0.4804 | 20 / 20 | 16 / 56 |
| 1 | 0.5567 | 0.6242 | 0.5567 | 20 / 20 | 25 / 69 |
| 2 | 0.5479 | 0.6302 | 0.5479 | 20 / 20 | 18 / 75 |
| 3 | 0.5420 | 0.5997 | 0.5420 | 20 / 20 | 45 / 126 |
| 4 | 0.6502 | 0.6980 | 0.6502 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6326 ± 0.0384
