# BLCA — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6419 ± 0.0348 | [0.599, 0.685] | 0.6365 | 0.1622 | 0.6852 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6394 | nan | nan | -1 / 0 | 25 / 70 |
| 1 | 0.6296 | nan | nan | -1 / 0 | 24 / 72 |
| 2 | 0.6855 | nan | nan | -1 / 0 | 23 / 75 |
| 3 | 0.5930 | nan | nan | -1 / 0 | 25 / 71 |
| 4 | 0.6619 | nan | nan | -1 / 0 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
