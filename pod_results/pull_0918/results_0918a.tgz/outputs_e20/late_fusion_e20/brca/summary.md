# BRCA — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5918 ± 0.0863 | [0.485, 0.699] | 0.6252 | 0.0680 | 0.6664 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5928 | nan | nan | -1 / 0 | 8 / 176 |
| 1 | 0.5078 | nan | nan | -1 / 0 | 9 / 168 |
| 2 | 0.6945 | nan | nan | -1 / 0 | 20 / 182 |
| 3 | 0.5044 | nan | nan | -1 / 0 | 7 / 166 |
| 4 | 0.6596 | nan | nan | -1 / 0 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
