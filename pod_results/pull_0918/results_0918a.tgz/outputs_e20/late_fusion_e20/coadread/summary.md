# COADREAD — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5710 ± 0.1702 | [0.360, 0.782] | 0.5692 | 0.0697 | 0.6301 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7927 | nan | nan | -1 / 0 | 5 / 58 |
| 1 | 0.4882 | nan | nan | -1 / 0 | 13 / 71 |
| 2 | 0.3365 | nan | nan | -1 / 0 | 5 / 45 |
| 3 | 0.6314 | nan | nan | -1 / 0 | 9 / 67 |
| 4 | 0.6061 | nan | nan | -1 / 0 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
