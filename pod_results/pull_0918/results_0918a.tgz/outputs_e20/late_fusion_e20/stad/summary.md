# STAD — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5486 ± 0.1060 | [0.417, 0.680] | 0.5632 | 0.1690 | 0.5500 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.3808 | nan | nan | -1 / 0 | 10 / 42 |
| 1 | 0.6459 | nan | nan | -1 / 0 | 16 / 56 |
| 2 | 0.5265 | nan | nan | -1 / 0 | 16 / 101 |
| 3 | 0.6308 | nan | nan | -1 / 0 | 9 / 45 |
| 4 | 0.5591 | nan | nan | -1 / 0 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
