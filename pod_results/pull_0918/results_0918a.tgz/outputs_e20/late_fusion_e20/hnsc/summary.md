# HNSC — 5-fold CV (DSS, selection: late_fusion)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5778 ± 0.0345 | [0.535, 0.621] | 0.5931 | 0.1759 | 0.5696 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5472 | nan | nan | -1 / 0 | 16 / 56 |
| 1 | 0.5726 | nan | nan | -1 / 0 | 25 / 69 |
| 2 | 0.5919 | nan | nan | -1 / 0 | 18 / 75 |
| 3 | 0.5476 | nan | nan | -1 / 0 | 45 / 126 |
| 4 | 0.6297 | nan | nan | -1 / 0 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): nan ± nan
