# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5244 ± 0.1030 | [0.397, 0.652] | 0.5396 | 0.2040 | 0.5064 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4305 | 0.5728 | 0.4305 | 20 / 20 | 10 / 42 |
| 1 | 0.4257 | 0.5769 | 0.4257 | 20 / 20 | 16 / 56 |
| 2 | 0.5029 | 0.6337 | 0.5029 | 20 / 20 | 16 / 101 |
| 3 | 0.6462 | 0.7231 | 0.6462 | 20 / 20 | 9 / 45 |
| 4 | 0.6169 | 0.6317 | 0.6169 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6276 ± 0.0607
