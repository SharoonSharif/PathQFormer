# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6194 ± 0.0807 | [0.519, 0.720] | 0.6149 | 0.1883 | 0.6822 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6115 | 0.6471 | 0.6115 | 20 / 20 | 25 / 70 |
| 1 | 0.5696 | 0.6973 | 0.5696 | 20 / 20 | 24 / 72 |
| 2 | 0.7551 | 0.7838 | 0.7551 | 20 / 20 | 23 / 75 |
| 3 | 0.5486 | 0.6742 | 0.5486 | 20 / 20 | 25 / 71 |
| 4 | 0.6122 | 0.6993 | 0.6122 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7003 ± 0.0512
