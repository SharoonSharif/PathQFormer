# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5410 ± 0.0841 | [0.437, 0.645] | 0.5481 | 0.2047 | 0.5653 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4383 | 0.5428 | 0.4383 | 20 / 20 | 16 / 56 |
| 1 | 0.5459 | 0.5951 | 0.5459 | 20 / 20 | 25 / 69 |
| 2 | 0.6719 | 0.7407 | 0.6719 | 20 / 20 | 18 / 75 |
| 3 | 0.5266 | 0.5848 | 0.5266 | 20 / 20 | 45 / 126 |
| 4 | 0.5222 | 0.5580 | 0.5222 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6043 ± 0.0790
