# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6299 ± 0.1390 | [0.457, 0.802] | 0.6234 | 0.0809 | 0.6612 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7886 | 0.9065 | 0.7886 | 20 / 20 | 5 / 58 |
| 1 | 0.5706 | 0.6549 | 0.5706 | 20 / 20 | 13 / 71 |
| 2 | 0.4231 | 0.6346 | 0.4231 | 20 / 20 | 5 / 45 |
| 3 | 0.6883 | 0.6883 | 0.6883 | 20 / 20 | 9 / 67 |
| 4 | 0.6788 | 0.8182 | 0.6788 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7405 ± 0.1171
