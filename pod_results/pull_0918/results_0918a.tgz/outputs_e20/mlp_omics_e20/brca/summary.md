# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6295 ± 0.0767 | [0.534, 0.725] | 0.5852 | 0.0765 | 0.6603 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5189 | 0.7457 | 0.5189 | 20 / 20 | 8 / 176 |
| 1 | 0.7255 | 0.7774 | 0.7255 | 20 / 20 | 9 / 168 |
| 2 | 0.6174 | 0.6499 | 0.6174 | 20 / 20 | 20 / 182 |
| 3 | 0.6145 | 0.7599 | 0.6145 | 20 / 20 | 7 / 166 |
| 4 | 0.6710 | 0.6885 | 0.6710 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7243 ± 0.0533
