# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6507 ± 0.1421 | [0.474, 0.827] | 0.6729 | 0.0817 | 0.6532 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8537 | 0.8902 | 0.8537 | 20 / 20 | 5 / 58 |
| 1 | 0.5667 | 0.5971 | 0.5667 | 20 / 20 | 13 / 71 |
| 2 | 0.4808 | 0.7692 | 0.4808 | 20 / 20 | 5 / 45 |
| 3 | 0.7100 | 0.7127 | 0.7100 | 20 / 20 | 9 / 67 |
| 4 | 0.6424 | 0.6667 | 0.6424 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7272 ± 0.1109
