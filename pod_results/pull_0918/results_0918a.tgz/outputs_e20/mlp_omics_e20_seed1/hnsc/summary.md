# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5611 ± 0.0554 | [0.492, 0.630] | 0.5688 | 0.2000 | 0.5680 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4993 | 0.6009 | 0.4993 | 20 / 20 | 16 / 56 |
| 1 | 0.5623 | 0.6157 | 0.5623 | 20 / 20 | 25 / 69 |
| 2 | 0.6505 | 0.7542 | 0.6505 | 20 / 20 | 18 / 75 |
| 3 | 0.5508 | 0.5738 | 0.5508 | 20 / 20 | 45 / 126 |
| 4 | 0.5427 | 0.5717 | 0.5427 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6233 ± 0.0755
