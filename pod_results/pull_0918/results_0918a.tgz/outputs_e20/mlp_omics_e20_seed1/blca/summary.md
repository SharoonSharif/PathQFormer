# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5971 ± 0.1016 | [0.471, 0.723] | 0.5905 | 0.1913 | 0.6694 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5813 | 0.7067 | 0.5813 | 20 / 20 | 25 / 70 |
| 1 | 0.5174 | 0.7128 | 0.5174 | 20 / 20 | 24 / 72 |
| 2 | 0.7541 | 0.7746 | 0.7541 | 20 / 20 | 23 / 75 |
| 3 | 0.5024 | 0.5864 | 0.5024 | 20 / 20 | 25 / 71 |
| 4 | 0.6302 | 0.6547 | 0.6302 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6870 ± 0.0705
