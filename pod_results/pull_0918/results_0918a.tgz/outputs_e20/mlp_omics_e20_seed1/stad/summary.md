# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5279 ± 0.0626 | [0.450, 0.606] | 0.5500 | 0.2058 | 0.5269 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4702 | 0.6358 | 0.4702 | 20 / 20 | 10 / 42 |
| 1 | 0.5095 | 0.5561 | 0.5095 | 20 / 20 | 16 / 56 |
| 2 | 0.4759 | 0.6502 | 0.4759 | 20 / 20 | 16 / 101 |
| 3 | 0.6154 | 0.6615 | 0.6154 | 20 / 20 | 9 / 45 |
| 4 | 0.5685 | 0.6552 | 0.5685 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6318 ± 0.0433
