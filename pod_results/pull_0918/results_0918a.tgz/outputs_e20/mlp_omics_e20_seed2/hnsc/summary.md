# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5623 ± 0.0785 | [0.465, 0.660] | 0.5729 | 0.1952 | 0.5818 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4920 | 0.5718 | 0.4920 | 20 / 20 | 16 / 56 |
| 1 | 0.6111 | 0.6336 | 0.6111 | 20 / 20 | 25 / 69 |
| 2 | 0.6753 | 0.7328 | 0.6753 | 20 / 20 | 18 / 75 |
| 3 | 0.5025 | 0.6389 | 0.5025 | 20 / 20 | 45 / 126 |
| 4 | 0.5307 | 0.5546 | 0.5307 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6263 ± 0.0701
