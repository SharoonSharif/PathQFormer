# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5423 ± 0.1107 | [0.405, 0.680] | 0.5602 | 0.2029 | 0.5414 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4735 | 0.5497 | 0.4735 | 20 / 20 | 10 / 42 |
| 1 | 0.4326 | 0.5406 | 0.4326 | 20 / 20 | 16 / 56 |
| 2 | 0.5112 | 0.6914 | 0.5112 | 20 / 20 | 16 / 101 |
| 3 | 0.7154 | 0.7846 | 0.7154 | 20 / 20 | 9 / 45 |
| 4 | 0.5790 | 0.6418 | 0.5790 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6416 ± 0.1020
