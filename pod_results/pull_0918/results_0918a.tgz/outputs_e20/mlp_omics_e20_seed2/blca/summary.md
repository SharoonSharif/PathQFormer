# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6176 ± 0.0769 | [0.522, 0.713] | 0.6098 | 0.1921 | 0.6761 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5885 | 0.6077 | 0.5885 | 20 / 20 | 25 / 70 |
| 1 | 0.5812 | 0.6905 | 0.5812 | 20 / 20 | 24 / 72 |
| 2 | 0.7541 | 0.7930 | 0.7541 | 20 / 20 | 23 / 75 |
| 3 | 0.5694 | 0.6289 | 0.5694 | 20 / 20 | 25 / 71 |
| 4 | 0.5950 | 0.6748 | 0.5950 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6790 ± 0.0720
