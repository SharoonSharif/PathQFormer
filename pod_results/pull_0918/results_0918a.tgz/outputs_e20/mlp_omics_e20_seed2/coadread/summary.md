# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6195 ± 0.1618 | [0.419, 0.820] | 0.6418 | 0.0841 | 0.6918 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8049 | 0.8252 | 0.8049 | 20 / 20 | 5 / 58 |
| 1 | 0.6000 | 0.6637 | 0.6000 | 20 / 20 | 13 / 71 |
| 2 | 0.3654 | 0.6635 | 0.3654 | 20 / 20 | 5 / 45 |
| 3 | 0.6911 | 0.7507 | 0.6911 | 20 / 20 | 9 / 67 |
| 4 | 0.6364 | 0.7576 | 0.6364 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7321 ± 0.0690
