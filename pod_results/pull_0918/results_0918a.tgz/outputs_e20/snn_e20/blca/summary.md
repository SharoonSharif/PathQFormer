# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5988 ± 0.0836 | [0.495, 0.703] | 0.5914 | 0.2332 | 0.6531 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5909 | 0.6298 | 0.5909 | 20 / 20 | 25 / 70 |
| 1 | 0.5068 | 0.6480 | 0.5068 | 20 / 20 | 24 / 72 |
| 2 | 0.7326 | 0.7766 | 0.7326 | 20 / 20 | 23 / 75 |
| 3 | 0.5600 | 0.6176 | 0.5600 | 20 / 20 | 25 / 71 |
| 4 | 0.6036 | 0.6928 | 0.6036 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6730 ± 0.0646
