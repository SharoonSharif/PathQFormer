# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5519 ± 0.0489 | [0.491, 0.613] | 0.5639 | 0.0728 | 0.5877 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5206 | 0.7337 | 0.5206 | 20 / 20 | 8 / 176 |
| 1 | 0.5100 | 0.8521 | 0.5100 | 20 / 20 | 9 / 168 |
| 2 | 0.5195 | 0.6354 | 0.5195 | 20 / 20 | 20 / 182 |
| 3 | 0.6145 | 0.7896 | 0.6145 | 20 / 20 | 7 / 166 |
| 4 | 0.5948 | 0.6950 | 0.5948 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7411 ± 0.0837
