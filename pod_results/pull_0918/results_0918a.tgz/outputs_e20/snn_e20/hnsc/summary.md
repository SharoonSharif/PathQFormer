# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5358 ± 0.0793 | [0.437, 0.634] | 0.5385 | 0.2166 | 0.5356 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4659 | 0.5385 | 0.4659 | 20 / 20 | 16 / 56 |
| 1 | 0.4920 | 0.5904 | 0.4920 | 20 / 20 | 25 / 69 |
| 2 | 0.6674 | 0.7170 | 0.6674 | 20 / 20 | 18 / 75 |
| 3 | 0.5476 | 0.6063 | 0.5476 | 20 / 20 | 45 / 126 |
| 4 | 0.5060 | 0.5239 | 0.5060 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5952 ± 0.0763
