# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5433 ± 0.1540 | [0.352, 0.735] | 0.5558 | 0.0858 | 0.6025 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7154 | 0.8171 | 0.7154 | 20 / 20 | 5 / 58 |
| 1 | 0.5755 | 0.6706 | 0.5755 | 20 / 20 | 13 / 71 |
| 2 | 0.2933 | 0.7115 | 0.2933 | 20 / 20 | 5 / 45 |
| 3 | 0.5840 | 0.6951 | 0.5840 | 20 / 20 | 9 / 67 |
| 4 | 0.5485 | 0.6303 | 0.5485 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7049 ± 0.0698
