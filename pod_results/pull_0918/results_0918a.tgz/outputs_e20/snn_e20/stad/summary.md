# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5564 ± 0.0786 | [0.459, 0.654] | 0.5672 | 0.2336 | 0.5175 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4834 | 0.5513 | 0.4834 | 20 / 20 | 10 / 42 |
| 1 | 0.4801 | 0.5682 | 0.4801 | 20 / 20 | 16 / 56 |
| 2 | 0.5648 | 0.6596 | 0.5648 | 20 / 20 | 16 / 101 |
| 3 | 0.6692 | 0.6981 | 0.6692 | 20 / 20 | 9 / 45 |
| 4 | 0.5843 | 0.6035 | 0.5843 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6161 ± 0.0618
