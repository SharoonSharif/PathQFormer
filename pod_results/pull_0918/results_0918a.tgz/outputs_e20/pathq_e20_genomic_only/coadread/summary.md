# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5658 ± 0.0541 | [0.499, 0.633] | 0.5541 | 0.0717 | 0.5145 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5732 | 0.6585 | 0.5732 | 20 / 20 | 5 / 58 |
| 1 | 0.5569 | 0.7863 | 0.5569 | 20 / 20 | 13 / 71 |
| 2 | 0.4904 | 0.7596 | 0.4904 | 20 / 20 | 5 / 45 |
| 3 | 0.5664 | 0.7751 | 0.5664 | 20 / 20 | 9 / 67 |
| 4 | 0.6424 | 0.7182 | 0.6424 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7395 ± 0.0521
