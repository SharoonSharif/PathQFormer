# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5115 ± 0.0849 | [0.406, 0.617] | 0.5249 | 0.1821 | 0.4550 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4205 | 0.6987 | 0.4205 | 20 / 20 | 10 / 42 |
| 1 | 0.4819 | 0.7029 | 0.4819 | 20 / 20 | 16 / 56 |
| 2 | 0.4629 | 0.6125 | 0.4629 | 20 / 20 | 16 / 101 |
| 3 | 0.6346 | 0.6808 | 0.6346 | 20 / 20 | 9 / 45 |
| 4 | 0.5578 | 0.6331 | 0.5578 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6656 ± 0.0406
