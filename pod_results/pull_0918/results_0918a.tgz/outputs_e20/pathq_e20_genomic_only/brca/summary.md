# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5579 ± 0.1732 | [0.343, 0.773] | 0.5795 | 0.0668 | 0.5813 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6409 | 0.6873 | 0.6409 | 20 / 20 | 8 / 176 |
| 1 | 0.2646 | 0.7674 | 0.2646 | 20 / 20 | 9 / 168 |
| 2 | 0.6681 | 0.7061 | 0.6681 | 20 / 20 | 20 / 182 |
| 3 | 0.5374 | 0.6806 | 0.5374 | 20 / 20 | 7 / 166 |
| 4 | 0.6786 | 0.7129 | 0.6786 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7109 ± 0.0343
