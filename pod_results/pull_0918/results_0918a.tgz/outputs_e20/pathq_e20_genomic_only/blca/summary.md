# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.6313 ± 0.0576 | [0.560, 0.703] | 0.6313 | 0.1729 | 0.6832 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5548 | 0.6010 | 0.5548 | 20 / 20 | 25 / 70 |
| 1 | 0.6320 | 0.7485 | 0.6320 | 20 / 20 | 24 / 72 |
| 2 | 0.7070 | 0.7316 | 0.7070 | 20 / 20 | 23 / 75 |
| 3 | 0.6025 | 0.6242 | 0.6025 | 20 / 20 | 25 / 71 |
| 4 | 0.6604 | 0.6978 | 0.6604 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6806 ± 0.0653
