# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| genomic_only | 0.5630 ± 0.0498 | [0.501, 0.625] | 0.5743 | 0.2005 | 0.6108 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5457 | 0.6110 | 0.5457 | 20 / 20 | 16 / 56 |
| 1 | 0.5586 | 0.6607 | 0.5586 | 20 / 20 | 25 / 69 |
| 2 | 0.5750 | 0.5851 | 0.5750 | 20 / 20 | 18 / 75 |
| 3 | 0.4993 | 0.6046 | 0.4993 | 20 / 20 | 45 / 126 |
| 4 | 0.6365 | 0.6945 | 0.6365 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6312 ± 0.0451
