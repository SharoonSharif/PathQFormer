# STAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5674 ± 0.0726 | [0.477, 0.658] | 0.5697 | 0.2033 | 0.6192 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5894 | 0.6060 | 0.5894 | 20 / 20 | 10 / 42 |
| 1 | 0.6218 | 0.6805 | 0.6218 | 20 / 20 | 16 / 56 |
| 2 | 0.6443 | 0.6843 | 0.6443 | 20 / 20 | 16 / 101 |
| 3 | 0.4885 | 0.6808 | 0.4885 | 20 / 20 | 9 / 45 |
| 4 | 0.4933 | 0.5615 | 0.4933 | 20 / 20 | 33 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6426 ± 0.0560
