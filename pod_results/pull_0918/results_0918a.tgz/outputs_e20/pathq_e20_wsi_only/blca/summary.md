# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5926 ± 0.0908 | [0.480, 0.705] | 0.5921 | 0.2318 | 0.6388 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6885 | 0.7096 | 0.6885 | 20 / 20 | 25 / 70 |
| 1 | 0.6044 | 0.6093 | 0.6044 | 20 / 20 | 24 / 72 |
| 2 | 0.6424 | 0.6721 | 0.6424 | 20 / 20 | 23 / 75 |
| 3 | 0.4476 | 0.5940 | 0.4476 | 20 / 20 | 25 / 71 |
| 4 | 0.5799 | 0.7813 | 0.5799 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6733 ± 0.0764
