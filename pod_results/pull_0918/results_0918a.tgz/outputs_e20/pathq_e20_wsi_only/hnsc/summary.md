# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5865 ± 0.0496 | [0.525, 0.648] | 0.6006 | 0.2282 | 0.5660 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5356 | 0.6604 | 0.5356 | 20 / 20 | 16 / 56 |
| 1 | 0.6232 | 0.6345 | 0.6232 | 20 / 20 | 25 / 69 |
| 2 | 0.5321 | 0.6708 | 0.5321 | 20 / 20 | 18 / 75 |
| 3 | 0.6031 | 0.6110 | 0.6031 | 20 / 20 | 45 / 126 |
| 4 | 0.6382 | 0.6416 | 0.6382 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6437 ± 0.0233
