# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5960 ± 0.1402 | [0.422, 0.770] | 0.6248 | 0.0965 | 0.6192 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.4845 | 0.6804 | 0.4845 | 20 / 20 | 8 / 176 |
| 1 | 0.7767 | 0.7767 | 0.7767 | 20 / 20 | 9 / 168 |
| 2 | 0.6042 | 0.7256 | 0.6042 | 20 / 20 | 20 / 182 |
| 3 | 0.4339 | 0.6101 | 0.4339 | 20 / 20 | 7 / 166 |
| 4 | 0.6809 | 0.6992 | 0.6809 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6984 ± 0.0612
