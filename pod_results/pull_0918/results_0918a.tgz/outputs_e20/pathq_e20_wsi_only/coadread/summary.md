# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5876 ± 0.1544 | [0.396, 0.779] | 0.5884 | 0.0877 | 0.6234 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7764 | 0.8659 | 0.7764 | 20 / 20 | 5 / 58 |
| 1 | 0.5686 | 0.6353 | 0.5686 | 20 / 20 | 13 / 71 |
| 2 | 0.3558 | 0.9712 | 0.3558 | 20 / 20 | 5 / 45 |
| 3 | 0.6612 | 0.7967 | 0.6612 | 20 / 20 | 9 / 67 |
| 4 | 0.5758 | 0.7152 | 0.5758 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7968 ± 0.1303
