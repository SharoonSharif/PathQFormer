# BLCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5611 ± 0.0641 | [0.482, 0.641] | 0.5612 | 0.1967 | 0.6495 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5841 | 0.6769 | 0.5841 | 20 / 20 | 25 / 70 |
| 1 | 0.6074 | 0.6373 | 0.6074 | 20 / 20 | 24 / 72 |
| 2 | 0.6250 | 0.7561 | 0.6250 | 20 / 20 | 23 / 75 |
| 3 | 0.4740 | 0.5873 | 0.4740 | 20 / 20 | 25 / 71 |
| 4 | 0.5151 | 0.6791 | 0.5151 | 20 / 20 | 16 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6674 ± 0.0621
