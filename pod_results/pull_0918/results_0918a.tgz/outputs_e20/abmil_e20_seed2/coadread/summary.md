# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| wsi_only | 0.5608 ± 0.1783 | [0.339, 0.782] | 0.6126 | 0.0984 | 0.6116 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7846 | 0.8333 | 0.7846 | 20 / 20 | 5 / 58 |
| 1 | 0.3873 | 0.6549 | 0.3873 | 20 / 20 | 13 / 71 |
| 2 | 0.7115 | 0.8654 | 0.7115 | 20 / 20 | 5 / 45 |
| 3 | 0.5054 | 0.8022 | 0.5054 | 20 / 20 | 9 / 67 |
| 4 | 0.4152 | 0.6788 | 0.4152 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7669 ± 0.0944
