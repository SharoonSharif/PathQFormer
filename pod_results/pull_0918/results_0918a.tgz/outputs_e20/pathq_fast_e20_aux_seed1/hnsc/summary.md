# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5542 ± 0.0492 | [0.493, 0.615] | 0.5499 | 0.2430 | 0.5555 |
| genomic_only | 0.5247 ± 0.0830 | [0.422, 0.628] | 0.5250 | 0.2221 | 0.5093 |
| wsi_only | 0.5770 ± 0.0284 | [0.542, 0.612] | 0.5798 | 0.2355 | 0.5723 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5511 ± 0.0422 |
| 20% | 0.5502 ± 0.0519 |
| 30% | 0.5471 ± 0.0557 |
| 50% | 0.5517 ± 0.0391 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5675 | 0.6081 | 0.5675 | 20 / 20 | 16 / 56 |
| 1 | 0.6036 | 0.6195 | 0.6036 | 20 / 20 | 25 / 69 |
| 2 | 0.5750 | 0.7046 | 0.5750 | 20 / 20 | 18 / 75 |
| 3 | 0.5522 | 0.5640 | 0.5522 | 20 / 20 | 45 / 126 |
| 4 | 0.4727 | 0.5853 | 0.4727 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6163 ± 0.0538
