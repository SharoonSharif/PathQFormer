# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6054 ± 0.2510 | [0.294, 0.917] | 0.6247 | 0.0837 | 0.7152 |
| genomic_only | 0.5572 ± 0.2006 | [0.308, 0.806] | 0.5887 | 0.0745 | 0.6545 |
| wsi_only | 0.5912 ± 0.2099 | [0.330, 0.852] | 0.5962 | 0.0814 | 0.7315 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5992 ± 0.2361 |
| 20% | 0.6147 ± 0.2253 |
| 30% | 0.5902 ± 0.2425 |
| 50% | 0.5720 ± 0.2298 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.9187 | 0.9390 | 0.9187 | 20 / 20 | 5 / 58 |
| 1 | 0.5922 | 0.6529 | 0.5922 | 20 / 20 | 13 / 71 |
| 2 | 0.2212 | 0.7500 | 0.2212 | 20 / 20 | 5 / 45 |
| 3 | 0.6829 | 0.7398 | 0.6829 | 20 / 20 | 9 / 67 |
| 4 | 0.6121 | 0.7394 | 0.6121 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7642 ± 0.1053
