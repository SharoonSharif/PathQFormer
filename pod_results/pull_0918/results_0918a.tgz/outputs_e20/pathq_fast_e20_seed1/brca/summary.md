# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6455 ± 0.0947 | [0.528, 0.763] | 0.6874 | 0.0867 | 0.6813 |
| genomic_only | 0.6045 ± 0.0818 | [0.503, 0.706] | 0.5550 | 0.0663 | 0.6117 |
| wsi_only | 0.6516 ± 0.0703 | [0.564, 0.739] | 0.6522 | 0.0849 | 0.6573 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6403 ± 0.0987 |
| 20% | 0.6358 ± 0.0855 |
| 30% | 0.6468 ± 0.0932 |
| 50% | 0.6278 ± 0.1041 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6856 | 0.8351 | 0.6856 | 20 / 20 | 8 / 176 |
| 1 | 0.7198 | 0.7283 | 0.7198 | 20 / 20 | 9 / 168 |
| 2 | 0.5799 | 0.7478 | 0.5799 | 20 / 20 | 20 / 182 |
| 3 | 0.5132 | 0.5991 | 0.5132 | 20 / 20 | 7 / 166 |
| 4 | 0.7289 | 0.7563 | 0.7289 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7333 ± 0.0853
