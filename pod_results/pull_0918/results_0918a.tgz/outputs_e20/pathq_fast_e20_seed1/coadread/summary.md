# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6021 ± 0.1676 | [0.394, 0.810] | 0.6352 | 0.0811 | 0.6899 |
| genomic_only | 0.5394 ± 0.1394 | [0.366, 0.712] | 0.5557 | 0.0928 | 0.5445 |
| wsi_only | 0.6043 ± 0.1969 | [0.360, 0.849] | 0.6286 | 0.0777 | 0.7109 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6103 ± 0.1665 |
| 20% | 0.6164 ± 0.1516 |
| 30% | 0.6038 ± 0.1635 |
| 50% | 0.6100 ± 0.1539 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8699 | 0.9146 | 0.8699 | 20 / 20 | 5 / 58 |
| 1 | 0.5471 | 0.6412 | 0.5471 | 20 / 20 | 13 / 71 |
| 2 | 0.4615 | 0.7067 | 0.4615 | 20 / 20 | 5 / 45 |
| 3 | 0.6531 | 0.7453 | 0.6531 | 20 / 20 | 9 / 67 |
| 4 | 0.4788 | 0.7394 | 0.4788 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7494 ± 0.1012
