# HNSC — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5895 ± 0.0334 | [0.548, 0.631] | 0.6050 | 0.2091 | 0.6062 |
| genomic_only | 0.5348 ± 0.0536 | [0.468, 0.601] | 0.5351 | 0.2077 | 0.5468 |
| wsi_only | 0.6070 ± 0.0512 | [0.543, 0.671] | 0.6246 | 0.2112 | 0.6166 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5808 ± 0.0360 |
| 20% | 0.5843 ± 0.0318 |
| 30% | 0.5877 ± 0.0357 |
| 50% | 0.5758 ± 0.0366 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6226 | 0.7286 | 0.6226 | 20 / 20 | 16 / 56 |
| 1 | 0.6101 | 0.6457 | 0.6101 | 20 / 20 | 25 / 69 |
| 2 | 0.5953 | 0.6505 | 0.5953 | 20 / 20 | 18 / 75 |
| 3 | 0.5836 | 0.6337 | 0.5836 | 20 / 20 | 45 / 126 |
| 4 | 0.5358 | 0.6229 | 0.5358 | 20 / 20 | 13 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6563 ± 0.0418
