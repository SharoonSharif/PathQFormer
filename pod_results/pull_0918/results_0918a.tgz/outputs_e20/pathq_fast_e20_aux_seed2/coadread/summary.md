# COADREAD — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6395 ± 0.1879 | [0.406, 0.873] | 0.6432 | 0.0734 | 0.7111 |
| genomic_only | 0.5972 ± 0.1924 | [0.358, 0.836] | 0.6079 | 0.0856 | 0.6582 |
| wsi_only | 0.5899 ± 0.2259 | [0.309, 0.870] | 0.6097 | 0.0840 | 0.7430 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6438 ± 0.1992 |
| 20% | 0.6309 ± 0.1968 |
| 30% | 0.6258 ± 0.1914 |
| 50% | 0.6386 ± 0.1632 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8496 | 0.9350 | 0.8496 | 20 / 20 | 5 / 58 |
| 1 | 0.6412 | 0.6765 | 0.6412 | 20 / 20 | 13 / 71 |
| 2 | 0.3365 | 0.7692 | 0.3365 | 20 / 20 | 5 / 45 |
| 3 | 0.6612 | 0.7019 | 0.6612 | 20 / 20 | 9 / 67 |
| 4 | 0.7091 | 0.7212 | 0.7091 | 20 / 20 | 5 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7608 ± 0.1031
