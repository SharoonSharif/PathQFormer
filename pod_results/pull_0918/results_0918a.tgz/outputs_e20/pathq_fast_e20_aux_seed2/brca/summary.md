# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5853 ± 0.1260 | [0.429, 0.742] | 0.6393 | 0.0732 | 0.6187 |
| genomic_only | 0.6124 ± 0.0518 | [0.548, 0.677] | 0.5787 | 0.0667 | 0.6086 |
| wsi_only | 0.5394 ± 0.1794 | [0.317, 0.762] | 0.6130 | 0.0900 | 0.5733 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5975 ± 0.1128 |
| 20% | 0.5869 ± 0.0991 |
| 30% | 0.5925 ± 0.0993 |
| 50% | 0.5637 ± 0.0967 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6271 | 0.6856 | 0.6271 | 20 / 20 | 8 / 176 |
| 1 | 0.6401 | 0.7852 | 0.6401 | 20 / 20 | 9 / 168 |
| 2 | 0.6042 | 0.6691 | 0.6042 | 20 / 20 | 20 / 182 |
| 3 | 0.3667 | 0.6608 | 0.3667 | 20 / 20 | 7 / 166 |
| 4 | 0.6881 | 0.6893 | 0.6881 | 20 / 20 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6980 ± 0.0501
