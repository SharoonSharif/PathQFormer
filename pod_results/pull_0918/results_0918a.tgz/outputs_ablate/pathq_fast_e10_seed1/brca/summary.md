# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5772 ± 0.1573 | [0.382, 0.773] | 0.6406 | 0.0682 | 0.6068 |
| genomic_only | 0.5472 ± 0.0872 | [0.439, 0.655] | 0.5101 | 0.0663 | 0.5748 |
| wsi_only | 0.5779 ± 0.1414 | [0.402, 0.753] | 0.6348 | 0.0683 | 0.6054 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5713 ± 0.1490 |
| 20% | 0.5694 ± 0.1465 |
| 30% | 0.5812 ± 0.1366 |
| 50% | 0.5571 ± 0.1670 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6271 | 0.7234 | 0.6271 | 10 / 10 | 8 / 176 |
| 1 | 0.7440 | 0.7667 | 0.7440 | 10 / 10 | 9 / 168 |
| 2 | 0.5604 | 0.6544 | 0.5604 | 10 / 10 | 20 / 182 |
| 3 | 0.3216 | 0.5242 | 0.3216 | 10 / 10 | 7 / 166 |
| 4 | 0.6329 | 0.6915 | 0.6329 | 10 / 10 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6720 ± 0.0924
