# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5345 ± 0.1358 | [0.366, 0.703] | 0.5173 | 0.1432 | 0.5320 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5120 | 0.6151 | 0.5120 | 10 / 10 | 8 / 176 |
| 1 | 0.5789 | 0.7354 | 0.5789 | 10 / 10 | 9 / 168 |
| 2 | 0.6169 | 0.7071 | 0.6169 | 10 / 10 | 20 / 182 |
| 3 | 0.3106 | 0.7093 | 0.3106 | 10 / 10 | 7 / 166 |
| 4 | 0.6542 | 0.7586 | 0.6542 | 10 / 10 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7051 ± 0.0545
