# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5512 ± 0.0764 | [0.456, 0.646] | 0.5481 | 0.1246 | 0.5359 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5601 | 0.7010 | 0.5601 | 10 / 10 | 8 / 176 |
| 1 | 0.5491 | 0.7383 | 0.5491 | 10 / 10 | 9 / 168 |
| 2 | 0.6734 | 0.6810 | 0.6734 | 10 / 10 | 20 / 182 |
| 3 | 0.4868 | 0.5374 | 0.4868 | 10 / 10 | 7 / 166 |
| 4 | 0.4867 | 0.7372 | 0.4867 | 10 / 10 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6790 ± 0.0828
