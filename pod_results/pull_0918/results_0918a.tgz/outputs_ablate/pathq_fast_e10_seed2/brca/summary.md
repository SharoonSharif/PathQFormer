# BRCA — 5-fold CV (DSS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.6349 ± 0.0558 | [0.566, 0.704] | 0.6260 | 0.0796 | 0.6379 |
| genomic_only | 0.5738 ± 0.1043 | [0.444, 0.703] | 0.5327 | 0.0704 | 0.5952 |
| wsi_only | 0.5780 ± 0.1585 | [0.381, 0.775] | 0.6510 | 0.0816 | 0.6244 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.6391 ± 0.0558 |
| 20% | 0.6070 ± 0.0691 |
| 30% | 0.6139 ± 0.0770 |
| 50% | 0.5938 ± 0.0722 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.6340 | 0.7062 | 0.6340 | 10 / 10 | 8 / 176 |
| 1 | 0.7041 | 0.7155 | 0.7041 | 10 / 10 | 9 / 168 |
| 2 | 0.5546 | 0.7079 | 0.5546 | 10 / 10 | 20 / 182 |
| 3 | 0.6167 | 0.6652 | 0.6167 | 10 / 10 | 7 / 166 |
| 4 | 0.6649 | 0.7174 | 0.6649 | 10 / 10 | 16 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7024 ± 0.0214
