# COADREAD — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5960 ± 0.1530 | [0.406, 0.786] | 0.5828 | 0.2560 | 0.4625 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.8398 | 0.8828 | 0.8398 | 20 / 20 | 6 / 58 |
| 1 | 0.4827 | 0.5467 | 0.4827 | 20 / 20 | 19 / 71 |
| 2 | 0.5436 | 0.7047 | 0.5436 | 20 / 20 | 8 / 45 |
| 3 | 0.6453 | 0.8140 | 0.6453 | 20 / 20 | 13 / 67 |
| 4 | 0.4688 | 0.6250 | 0.4688 | 20 / 20 | 12 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7146 ± 0.1365
