# BLCA — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5521 ± 0.0559 | [0.483, 0.622] | 0.5550 | 0.3632 | 0.6165 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5469 | 0.6471 | 0.5469 | 20 / 20 | 28 / 70 |
| 1 | 0.6288 | 0.6859 | 0.6288 | 20 / 20 | 38 / 72 |
| 2 | 0.5533 | 0.6670 | 0.5533 | 20 / 20 | 27 / 75 |
| 3 | 0.4713 | 0.5761 | 0.4713 | 20 / 20 | 35 / 71 |
| 4 | 0.5605 | 0.6556 | 0.5605 | 20 / 20 | 28 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6464 ± 0.0418
