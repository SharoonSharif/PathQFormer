# HNSC — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5104 ± 0.0288 | [0.475, 0.546] | 0.5181 | 0.3575 | 0.4984 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5033 | 0.6202 | 0.5033 | 20 / 20 | 18 / 56 |
| 1 | 0.5423 | 0.5749 | 0.5423 | 20 / 20 | 28 / 69 |
| 2 | 0.5060 | 0.5284 | 0.5060 | 20 / 20 | 30 / 75 |
| 3 | 0.5320 | 0.5824 | 0.5320 | 20 / 20 | 80 / 126 |
| 4 | 0.4685 | 0.5719 | 0.4685 | 20 / 20 | 20 / 66 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.5756 ± 0.0327
