# STAD — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5590 ± 0.0451 | [0.503, 0.615] | 0.5671 | 0.3026 | 0.5566 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5464 | 0.6689 | 0.5464 | 20 / 20 | 10 / 42 |
| 1 | 0.6330 | 0.6374 | 0.6330 | 20 / 20 | 18 / 56 |
| 2 | 0.5344 | 0.6372 | 0.5344 | 20 / 20 | 40 / 101 |
| 3 | 0.5652 | 0.6823 | 0.5652 | 20 / 20 | 11 / 45 |
| 4 | 0.5161 | 0.5622 | 0.5161 | 20 / 20 | 41 / 74 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6376 ± 0.0465
