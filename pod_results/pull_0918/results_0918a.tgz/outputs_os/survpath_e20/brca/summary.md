# BRCA — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5234 ± 0.0517 | [0.459, 0.588] | 0.5627 | 0.2245 | 0.5453 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5368 | 0.6586 | 0.5368 | 20 / 20 | 10 / 176 |
| 1 | 0.4731 | 0.5726 | 0.4731 | 20 / 20 | 15 / 168 |
| 2 | 0.5331 | 0.6964 | 0.5331 | 20 / 20 | 33 / 182 |
| 3 | 0.4755 | 0.6827 | 0.4755 | 20 / 20 | 13 / 166 |
| 4 | 0.5983 | 0.6559 | 0.5983 | 20 / 20 | 31 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6532 ± 0.0482
