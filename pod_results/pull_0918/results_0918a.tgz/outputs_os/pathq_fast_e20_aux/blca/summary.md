# BLCA — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5954 ± 0.0532 | [0.529, 0.661] | 0.5868 | 0.2810 | 0.6639 |
| genomic_only | 0.5917 ± 0.0581 | [0.520, 0.664] | 0.6007 | 0.2474 | 0.6505 |
| wsi_only | 0.5758 ± 0.0712 | [0.487, 0.664] | 0.5589 | 0.2897 | 0.6242 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5974 ± 0.0498 |
| 20% | 0.6056 ± 0.0498 |
| 30% | 0.5969 ± 0.0460 |
| 50% | 0.5905 ± 0.0419 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5778 | 0.6202 | 0.5778 | 20 / 20 | 28 / 70 |
| 1 | 0.6499 | 0.6679 | 0.6499 | 20 / 20 | 38 / 72 |
| 2 | 0.6016 | 0.6714 | 0.6016 | 20 / 20 | 27 / 75 |
| 3 | 0.5144 | 0.5632 | 0.5144 | 20 / 20 | 35 / 71 |
| 4 | 0.6331 | 0.6419 | 0.6331 | 20 / 20 | 28 / 71 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6329 ± 0.0442
