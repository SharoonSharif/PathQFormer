# BRCA — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5963 ± 0.0427 | [0.543, 0.649] | 0.5521 | 0.1212 | 0.5402 |
| genomic_only | 0.5558 ± 0.0698 | [0.469, 0.642] | 0.5279 | 0.1332 | 0.5662 |
| wsi_only | 0.5309 ± 0.1341 | [0.364, 0.697] | 0.4887 | 0.1564 | 0.4937 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5900 ± 0.0419 |
| 20% | 0.5901 ± 0.0420 |
| 30% | 0.5797 ± 0.0238 |
| 50% | 0.5757 ± 0.0601 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.5609 | 0.6560 | 0.5609 | 20 / 20 | 10 / 176 |
| 1 | 0.5461 | 0.5621 | 0.5461 | 20 / 20 | 15 / 168 |
| 2 | 0.6294 | 0.7312 | 0.6294 | 20 / 20 | 33 / 182 |
| 3 | 0.5998 | 0.7328 | 0.5998 | 20 / 20 | 13 / 166 |
| 4 | 0.6453 | 0.6523 | 0.6453 | 20 / 20 | 31 / 176 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.6669 ± 0.0703
