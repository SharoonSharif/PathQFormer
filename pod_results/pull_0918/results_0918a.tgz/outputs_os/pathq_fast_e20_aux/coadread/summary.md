# COADREAD — 5-fold CV (OS, selection: last)

| Test-time modalities | C-index (mean ± std) | 95% CI | IPCW C-index | IBS | td-AUC |
|---|---|---|---|---|---|
| both | 0.5808 ± 0.1316 | [0.417, 0.744] | 0.5884 | 0.1782 | 0.6080 |
| genomic_only | 0.5620 ± 0.1765 | [0.343, 0.781] | 0.5926 | 0.1541 | 0.5626 |
| wsi_only | 0.5863 ± 0.1125 | [0.447, 0.726] | 0.5938 | 0.1870 | 0.6087 |

| Patients missing one modality | C-index |
|---|---|
| 10% | 0.5782 ± 0.1308 |
| 20% | 0.5739 ± 0.1248 |
| 30% | 0.5803 ± 0.1189 |
| 50% | 0.5759 ± 0.1198 |

| Fold | C-index (selected) | best any epoch | last epoch | selected ep / run | val events |
|---|---|---|---|---|---|
| 0 | 0.7461 | 0.9180 | 0.7461 | 20 / 20 | 6 / 58 |
| 1 | 0.4307 | 0.5893 | 0.4307 | 20 / 20 | 19 / 71 |
| 2 | 0.5436 | 0.6913 | 0.5436 | 20 / 20 | 8 / 45 |
| 3 | 0.6860 | 0.8372 | 0.6860 | 20 / 20 | 13 / 67 |
| 4 | 0.4974 | 0.6927 | 0.4974 | 20 / 20 | 12 / 55 |

Optimistic (best epoch by val C-index, as in earlier logs): 0.7457 ± 0.1306
